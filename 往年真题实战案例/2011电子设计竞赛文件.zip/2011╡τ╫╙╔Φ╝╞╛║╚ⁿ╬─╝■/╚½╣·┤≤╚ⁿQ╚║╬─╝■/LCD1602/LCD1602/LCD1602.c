//*******************************************************//
#define LCD1602_GLOBALS
#include "LCD1602.h"
//*******************************************************//
void lcd_ready (void)
{
 	U16 t=500;
	while(t--);   
}

//******************************************************//

void WrData(U8 wd)
{
	LCD = wd;
	RS = 1;
	RW = 0;
	LE = 0;
	LE = 1;
	lcd_ready();
}

//*****************************************************//

void WrCom(U8 wc) 
{
	LCD = wc;
	RS = 0;
	RW = 0; 
	LE = 0;
	LE = 1;
	lcd_ready();
}
//*****************************************************//
void ClearLcd(void)
{
U8 j;
//��LCD
WrCom(0x80);
for(j=0;j<16;j++)
	{
	WrData(0xa0);
	}
WrCom(0xc0);
for(j=0;j<16;j++)
	{
	WrData(0xa0);
	}
}
//*****************************************************//
void Initlcd(void)
{
WrCom(0x38);
lcd_ready();
WrCom(0x38);
lcd_ready();
WrCom(0x38);
lcd_ready();
WrCom(0x38);
lcd_ready();
WrCom(0x08);
lcd_ready();
WrCom(0x01);
lcd_ready();
WrCom(0x06);
lcd_ready();
WrCom(0x0c);
lcd_ready();
}

//*****************************************************//
void Dis_U8(U8 Line,U8 Start_Add,U8 da)
{
//��ʾ����
if(Line==0)
	{
	WrCom(0x80+Start_Add);
	}
else
	{
	WrCom(0xc0+Start_Add);
	}
//дʮλ
WrData(da / 10 +'0');
//д��λ
WrData(da % 10 +'0');
}

//*******************************************************//
void Dis_str(U8 Line,U8 Start_Add,U8 *str)

{
U8 i=0;
//�����ʾ����
if(Line==0)
	{
	WrCom(0x80+Start_Add);
	}
else
	{
	WrCom(0xc0+Start_Add);
	}
for(i=0;i<16;i++)
	{
	WrData(0xa0);
	}
//��ʾ����
if(Line==0)
	{
	WrCom(0x80+Start_Add);
	}
else
	{
	WrCom(0xc0+Start_Add);
	}
for(i=0;str[i]!='\0';i++)
	{
	WrData(str[i]);
	}
}
//*******************************************************//

