#ifndef _LCD12864_H_
#define _LCD12864_H_
#include "stc12c5a60s2.h"

sbit E_CLK=P0^5;
sbit RW_SID=P0^6;

extern unsigned char KeyFuncIndex;

extern void LCD12864_Init(void);

extern xdata float Basic02SetValue;		//����2�趨ֵ
extern xdata unsigned int Basic03SetValue;    		//����3�趨ֵ
extern xdata unsigned char High01SetValue;  //����1�趨ֵ

void MenuOperate(unsigned char key);
#endif