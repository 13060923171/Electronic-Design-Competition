#ifndef _STC12UART2_H_
#define _STC12UART2_H_

#define FOSC 11059200L
#define BAUD 9600

#define S2RI 0x01
#define S2TI 0x02
#define S2RB8 0x04
#define S2TB8 0x08

extern bit RecFlag;
extern unsigned char Uart2Rec;

//extern void UART2_SendStr(char *s);
extern void UART2_Init();

extern xdata unsigned char ucStrAngle[6],ucStra[6],ucStrw[6];//,;

extern xdata short mpu[9];
#endif