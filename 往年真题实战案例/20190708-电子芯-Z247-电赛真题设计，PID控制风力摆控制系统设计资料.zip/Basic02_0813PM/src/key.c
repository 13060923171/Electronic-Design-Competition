#include"key.h"
//�������ų�ʼ��
void KeyInit(void)
{
	io_key_1=1;
	io_key_2=1;
	io_key_3=1;
	io_key_4=1;
}
//Ӳ��������������
static uchar KeyScan(void)
{
	if(io_key_1==0) return KEY_VALUE_1;
	if(io_key_2==0) return KEY_VALUE_2;
	if(io_key_3==0) return KEY_VALUE_3;
	if(io_key_4==0) return KEY_VALUE_4;
	return KEY_NULL;
}
//�ϲ㰴��ɨ�躯��
void GetKey(uchar *pKeyValue)
{
	static uchar KeyState=KEY_STATE_INIT;
	static uchar KeyTimeCount=0;
	static uchar LastKey=KEY_NULL;
	uchar KeyTemp=KEY_NULL;

	KeyTemp=KeyScan();//��ȡ��ֵ

	switch(KeyState)
	{
		case KEY_STATE_INIT:
		{
			if(KEY_NULL!=(KeyTemp))
			{
				KeyState=KEY_STATE_WOBBLE;
			}
		}
		break;
		
		case KEY_STATE_WOBBLE:
		{
			KeyState=KEY_STATE_PRESS;
		}
		break;

		case KEY_STATE_PRESS:
		{
			if(KEY_NULL!=(KeyTemp))
			{
				LastKey=KeyTemp;
				
				KeyTemp|=KEY_DOWN;
				KeyState=KEY_STATE_LONG;	
			}
			else
			{
				KeyState=KEY_STATE_INIT;
			}
		}
		break;

		case KEY_STATE_LONG:
		{
			if(KEY_NULL!=(KeyTemp))
			{
				if(++KeyTimeCount>KEY_LONG_PERIOD)
				{
					KeyTimeCount=0;
					KeyTemp|=KEY_LONG;
					KeyState=KEY_STATE_CONTINUE;
				}
			}
			else
			{
				KeyState=KEY_STATE_RELEASE;
			}
		}
		break;

		case KEY_STATE_CONTINUE:
		{
			if(KEY_NULL!=(KeyTemp))
			{
				if(++KeyTimeCount>KEY_CONTINUE_PERIOD)
				{
					KeyTimeCount=0;
					KeyTemp|=KEY_CONTINUE;
				}
			}
			else
			{
				KeyState=KEY_STATE_RELEASE;
			}
		}
		break;

		case KEY_STATE_RELEASE:
		{
			LastKey|=KEY_UP;
			KeyTemp=LastKey;
			KeyState=KEY_STATE_INIT;
		}
		break;

		default:break;

	}
	*pKeyValue=KeyTemp;//���ؼ�ֵ
}











