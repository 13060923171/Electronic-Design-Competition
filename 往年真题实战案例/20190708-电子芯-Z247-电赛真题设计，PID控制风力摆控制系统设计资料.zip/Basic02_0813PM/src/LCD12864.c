
#include "LCD12864.h"
#include <intrins.h>
#include<stdio.h>

//�˵���ʵ��
/*-------------------------------------------------------------*/
#define MENU_SIZE 18             //�˵�����

unsigned char KeyFuncIndex=0;    //��ŵ�ǰ�Ĳ˵�����
bit Basic02Flag=0;  //��������2��־λ
bit Basic02IsOk=0;
//bit Basic02Return=0;
bit Basic03Flag=0;	//��������3��־λ
bit Basic03IsOk=0;

bit High01Flag=0;
bit	High01IsOk=0;	//  ���Ӳ���1��־

xdata float Basic02SetValue=0;		//����2�趨ֵ
xdata unsigned int Basic03SetValue=0;    		//����3�趨ֵ
xdata unsigned char High01SetValue=0;  //����1�趨ֵ
static xdata unsigned char LeghtNumber=30;
static xdata unsigned int  AngleNumber=0;
static xdata unsigned char RNumber=15;  //Բ�İ뾶

void (*KeyFuncPtr)();            //���尴������ָ��
//�������� 

typedef struct 
{
   unsigned char KeyStateIndex;   //��ǰ��״̬������
   unsigned char KeyDownState;    //�������¼�ʱ��״̬������
   unsigned char KeyUpState;      //�������ϼ�ʱ��״̬������
   unsigned char KeyEnterState;   //���»س���ʱ��״̬������
   void (*CurrentOperate)();      //��ǰ״̬Ӧ��ִ�еĹ��ܲ���
}  StateTab;
//
//
unsigned char code s0[]="BasicWork       ";
unsigned char code s1[]="HighWork        ";
unsigned char code s2[]="Basic01         ";
unsigned char code s3[]="Basic02         ";
unsigned char code s4[]="Basic03         ";
unsigned char code s5[]="Basic04         ";
unsigned char code s6[]="High01          ";
unsigned char code s7[]="High02          ";
unsigned char code s8[]="High03          ";
unsigned char code s9[]="Cancel          ";
unsigned char code s10[]="                ";
xdata	unsigned char s11[]="                ";
xdata   unsigned char s12[]="                ";
xdata   unsigned char s13[]="                ";
unsigned char code str[]="> ";
/*-------------------------------------------------------------*/
/*****************************
***功能：串行发送一字节数据
***输入参数：dat-要发送的字节
***输出参数：--
*****************************/
void SendByte(unsigned char dat)
{	
	unsigned char i;
    for(i=0;i<8;i++)	  
   {	
   		E_CLK=0;
        if(dat&0x80)
			RW_SID=1;
		else 
			RW_SID=0;
        E_CLK=1;

        dat=dat<<1;
    }
}
/*******************************
***	功能：写入命令
*** 输入参数：com-写命令
*** 输出参数：----------
*******************************/
void SendCMD(unsigned char com)
{	
	SendByte(0xF8);//11111,00,0     RW=0,RS=0     同步标志
    SendByte(com&0xF0);//高四位
    SendByte((com&0x0F)<<4);//低四位
}
//写显示数据或单字节字符
/*******************************
*** 功能：写入数据
*** 输入参数：dat-写数据
*** 输出参数；----------
*******************************/
void SendDat(unsigned char dat)
{	
	SendByte(0xFA);//11111,01,0     RW=0,RS=1
    SendByte(dat&0xF0);//高四位
    SendByte((dat&0x0F)<<4);//低四位
}
void Char_Set_XY(unsigned char x, unsigned char y, unsigned char *p)
{
	switch(y)
	{
		case 0:
			SendCMD(0x80+x);
		break;
		case 1:
			SendCMD(0x90+x);
		break;
		case 2:
			SendCMD(0x88+x);
		break;
		case 3:
			SendCMD(0x98+x);
		break;
	}
	while(*p!=0)
	{
		SendDat(*p++);
	}
}
void Stat0(void)
{

	Char_Set_XY(0,0,str);
	Char_Set_XY(1,0,s0);

	Char_Set_XY(0,1,s1);
	Char_Set_XY(0,2,s10);
	Char_Set_XY(0,3,s10);
}
/*-------------------------------------------------------------*/
void Stat1(void)
{	
	Char_Set_XY(0,0,s0);
	Char_Set_XY(0,1,str);
	Char_Set_XY(1,1,s1);

	Char_Set_XY(0,2,s10);
	Char_Set_XY(0,3,s10);
}
/*-------------------------------------------------------------*/
void Stat2(void)
{

	Char_Set_XY(0,0,str);
	Char_Set_XY(1,0,s2);

	Char_Set_XY(0,1,s3);
	Char_Set_XY(0,2,s4);
	Char_Set_XY(0,3,s5);

}
/*-------------------------------------------------------------*/
void Stat3(void)
{

	Char_Set_XY(0,0,s2);
	Char_Set_XY(0,1,str);
	Char_Set_XY(1,1,s3);

	Char_Set_XY(0,2,s4);
	Char_Set_XY(0,3,s5);

}
/*-------------------------------------------------------------*/
void Stat4(void)
{

	Char_Set_XY(0,0,s2);
	Char_Set_XY(0,2,str);
	Char_Set_XY(1,2,s4);
	Char_Set_XY(0,1,s3);



	Char_Set_XY(0,3,s5);

}
/*-------------------------------------------------------------*/
void Stat5(void)
{

	Char_Set_XY(0,0,s2);
	Char_Set_XY(0,1,s3);
	Char_Set_XY(0,2,s4);

	Char_Set_XY(0,3,str);
	Char_Set_XY(1,3,s5);

}
/*-------------------------------------------------------------*/
void Stat6(void)
{

	Char_Set_XY(0,0,str);
	Char_Set_XY(1,0,s6);

	Char_Set_XY(0,1,s7);
	Char_Set_XY(0,2,s8);
	Char_Set_XY(0,3,s9);

}
/*-------------------------------------------------------------*/
void Stat7(void)
{
	Char_Set_XY(0,0,s6);
	Char_Set_XY(0,1,str);
	Char_Set_XY(1,1,s7);

	Char_Set_XY(0,2,s8);
	Char_Set_XY(0,3,s9);


}
/*-------------------------------------------------------------*/
void Stat8(void)
{

	Char_Set_XY(0,0,s6);
	Char_Set_XY(0,2,str);
	Char_Set_XY(1,2,s8);
	Char_Set_XY(0,1,s7);


	Char_Set_XY(0,3,s9);

}
/*-------------------------------------------------------------*/
void Stat9(void)
{

	Char_Set_XY(0,0,s6);
	Char_Set_XY(0,1,s7);
	Char_Set_XY(0,2,s8);

	Char_Set_XY(0,3,str);
	Char_Set_XY(1,3,s9);


}	 
/*-------------------------------------------------------------*/
void Stat10(void)
{
    Char_Set_XY(0,0,s10);
	Char_Set_XY(0,1,"Basic01 is work-");
	Char_Set_XY(0,2,"ing......       ");
	Char_Set_XY(0,3,s10);
}
/*-------------------------------------------------------------*/
void Stat11(void)
{
	Char_Set_XY(0,0,"�趨����:(30~60)");
	Char_Set_XY(0,1,s11);
	if(Basic02IsOk)
	{	
		Char_Set_XY(0,2,"���趨");
	}
	else
	{
		Char_Set_XY(0,2,s10);	
	}
	Char_Set_XY(0,3,s10);
}
/*-------------------------------------------------------------*/
void Stat12(void)
{
	Char_Set_XY(0,0,"�趨�Ƕ�:(0~360)");
	Char_Set_XY(0,1,s12);
	if(Basic03IsOk)
	{
		Char_Set_XY(0,2,"���趨");
	}
	else
	{
		Char_Set_XY(0,2,s10);	
	}
	Char_Set_XY(0,3,s10);
}
/*-------------------------------------------------------------*/
void Stat13(void)
{
//	Char_Set_XY(0,0,s10);
//	Char_Set_XY(0,1,"High01  is work-");
//	Char_Set_XY(0,2,"ing......       ");
//	Char_Set_XY(0,3,s10);
	Char_Set_XY(0,0,"�趨�뾶:(15~35)");
	Char_Set_XY(0,1,s13);
	if(High01IsOk)
	{	
		Char_Set_XY(0,2,"���趨");
	}
	else
	{
		Char_Set_XY(0,2,s10);	
	}
	Char_Set_XY(0,3,s10);
}
/*-------------------------------------------------------------*/
void Stat14(void)
{
	Char_Set_XY(0,0,s10);
	Char_Set_XY(0,1,"High02  is work-");
	Char_Set_XY(0,2,"ing......       ");
	Char_Set_XY(0,3,s10);

}
/*-------------------------------------------------------------*/
void Stat15(void)
{
	Char_Set_XY(0,0,s10);
	Char_Set_XY(0,1,"High03  is work-");
	Char_Set_XY(0,2,"ing......       ");
	Char_Set_XY(0,3,s10);

}
/*-------------------------------------------------------------*/
void Stat16(void)
{
	Char_Set_XY(0,0,s10);
	Char_Set_XY(0,1,"Basic04 is work-");
	Char_Set_XY(0,2,"ing......       ");
	Char_Set_XY(0,3,s10);

}
/*-------------------------------------------------------------*/
 //���ݽṹ����
StateTab code KeyTab[MENU_SIZE]=
{
//��ǰ�����£����ϣ�ȷ��
   	{0,1,1,2,   (*Stat0)},    //����  ��ǰ��״̬������,�������¼�ʱ��״̬������,�������ϼ�ʱ��״̬������,���»س���ʱ��״̬������,��ǰ״̬Ӧ��ִ�еĹ��ܲ���
	{1,0,0,6,   (*Stat1)},	   //����

	{2,3,5,10,  (*Stat2)},     //����
	{3,4,2,11,  (*Stat3)},	   //����
	{4,5,3,12,  (*Stat4)},	   //����
	{5,2,4,16,   (*Stat5)},	   //����

	{6,7,9,13,  (*Stat6)},     //����
	{7,8,6,14,  (*Stat7)},     //
	{8,9,7,15,  (*Stat8)},   
	{9,6,8,1 ,  (*Stat9)},     //����

	{10,2,2,2,(*Stat10)},    //��		   LineTest
	{11,3,3,3,(*Stat11)},	   //		   RectTest
	{12,4,4,4,(*Stat12)},	   //          ImgTest

	{13,6,6,6,(*Stat13)},	    //��		Univercity
	{14,7,7,7,(*Stat14)},		//          E-Mail
 	{15,8,8,8,(*Stat15)},		//          QQ Numeber 

	{16,5,5,0,(*Stat16)}
};

/*-------------------------------------------------------------*/
void MenuOperate(unsigned char key)
{
	if(Basic02Flag)
	{
		switch(key)
		{
		    case  0x30:		       //���ϵļ�
			{
				LeghtNumber++;
				if(LeghtNumber==60)
					LeghtNumber=30;
			   // KeyFuncIndex=KeyTab[KeyFuncIndex].KeyUpState;
				break; 
			}
			case  0x28:			  //�س���
			{
				Basic02Flag=0;
				Basic02IsOk=1;
				Basic02SetValue=LeghtNumber;
				//	KeyFuncIndex=KeyTab[KeyFuncIndex].KeyEnterState;
				break; 
			}
			case  0x18:			  //���µļ�
			{
				LeghtNumber--;
				if(LeghtNumber==30)
					LeghtNumber=30;
				//	KeyFuncIndex=KeyTab[KeyFuncIndex].KeyDownState;
				break; 
			}
			//�˴����Ӱ����������
		}
		sprintf(s11,"Set:%d",(int)(LeghtNumber));
	}
	else if(Basic03Flag)
	{
		 switch(key)
		{
		    case  0x30:		       //���ϵļ�
			{
				AngleNumber+=10;
				if(AngleNumber>360)
					AngleNumber=360;
				break; 
			}
			case  0x28:			  //�س���
			{
				Basic03Flag=0;
				Basic03IsOk=1;
				Basic03SetValue=AngleNumber;
				break; 
			}
			case  0x18:			  //���µļ�
			{
				AngleNumber-=10;
				if(AngleNumber<0)
					AngleNumber=0;
				break; 
			}
			//�˴����Ӱ����������
		}
		sprintf(s12,"Set:%d",(int)(AngleNumber));
	}
	else if(High01Flag)
	{
		switch(key)
		{
		    case  0x30:		       //���ϵļ�
			{
				RNumber++;
				if(RNumber==35)
					RNumber=35;
			   // KeyFuncIndex=KeyTab[KeyFuncIndex].KeyUpState;
				break; 
			}
			case  0x28:			  //�س���
			{
				High01Flag=0;
				High01IsOk=1;
				High01SetValue=RNumber;
				//	KeyFuncIndex=KeyTab[KeyFuncIndex].KeyEnterState;
				break; 
			}
			case  0x18:			  //���µļ�
			{
				RNumber--;
				if(RNumber==15)
					RNumber=15;
				//	KeyFuncIndex=KeyTab[KeyFuncIndex].KeyDownState;
				break; 
			}
			//�˴����Ӱ����������
		}
		sprintf(s13,"Set:%d",(int)(RNumber));
	}
	else
	{
	    switch(key)
		{
		    case  0x30:		       //���ϵļ�
			{
			    KeyFuncIndex=KeyTab[KeyFuncIndex].KeyUpState;
				break; 
			}
			case  0x28:			  //�س���
			{
				KeyFuncIndex=KeyTab[KeyFuncIndex].KeyEnterState;
				break; 
			}
			case  0x18:			  //���µļ�
			{
				KeyFuncIndex=KeyTab[KeyFuncIndex].KeyDownState;
				break; 
			}
			//�˴����Ӱ����������
		}	
	}

	if((KeyFuncIndex==11)&&!Basic02IsOk)
	{
		Basic02Flag=1;		//����ָ�����2����
	}
	if((KeyFuncIndex==12)&&!Basic03IsOk)
	{
		Basic03Flag=1;      //���л���3�����趨
	}
	if((KeyFuncIndex==13)&&!High01IsOk)
	{
		High01Flag=1;
	}
	//������ִ�а����Ĳ���
	KeyFuncPtr=KeyTab[KeyFuncIndex].CurrentOperate;

	(*KeyFuncPtr)();     //ִ�е�ǰ�İ�������
}	 //*/


//void Delay(unsigned int Ms)
//{
//	unsigned int i,j;
//	while(Ms--)
//	{
//		for(i=0;i<50;i++)
//			for(j=0;j<10;j++)
//				;
//	}
//}
//void LCD12864_InitPicture()
//{
//	SendCMD(0x3E);
//	SendCMD(0x01);
//}

/*               写汉字到LCD     指定的位置
              x_add显示RAM的地址
              dat1/dat2显示汉字编码
*/
/******************************
***功能：初始化函数
***输入参数：------
***输出参数：------
*******************************/
//初始化     LCM
void LCD12864_Init(void)
{	
	SendCMD(0x30);//功能设置，一次送8位数据，基本指令集
    SendCMD(0x0C);//0000,1100       整体显示，游标off，游标位置off
    SendCMD(0x01);//0000,0001     清DDRAM
    SendCMD(0x02);//0000,0010     DDRAM地址归位
    SendCMD(0x80);//1000,0000     设定DDRAM     7位地址000，0000到地址计数器AC
}


