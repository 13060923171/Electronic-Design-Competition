#ifndef _PWM_H__
#define _PWM_H__
#include "STC12C5A60S2.h"

extern void HW_PWMInit (void);
extern void HW_PWM0Set (unsigned char a);
extern void HW_PWM1Set (unsigned char a);




#endif