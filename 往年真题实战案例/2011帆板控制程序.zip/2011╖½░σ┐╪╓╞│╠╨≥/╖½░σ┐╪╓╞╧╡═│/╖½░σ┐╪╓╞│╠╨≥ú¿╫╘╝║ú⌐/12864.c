#include"12864.h"

void delay__50us(uint t)
{
	uchar j;
	for(;t>0;t--)
		for(j=19;j>0;j--);
}

void Write_12864com(uchar com)
{
	RW=0;
	RS=0;
	delay__50us(1);
	P0=com;
	E=1;
	delay__50us(10);
	E=0;
	delay__50us(2);		
}
void Write_12864dat(uchar dat)
{
	RW=0;
	RS=1;
	delay__50us(1);
	P0=dat;
	E=1;
	delay__50us(10);
	E=0;
	delay__50us(2);		
}
void init_12864(void)
{
	delay__50us(2000);
	Write_12864com(0x30);	//����ָ�����
	delay__50us(4);
	Write_12864com(0x30);	//����ָ�����
	delay__50us(4);
	Write_12864com(0x0c);		//��ʾ״̬����
	delay__50us(4);
	Write_12864com(0x01);	   //���LCD����ʾ����
	delay__50us(240);
	Write_12864com(0x06);	//�α��Զ����ƣ����廭�治�ƶ�
	delay__50us(10);
}
void display_12864(uchar dat,uchar table[])
{
	uchar i;
	Write_12864com(dat);
	for(i=0;i<16;i++)
	{
		Write_12864dat(table[i]);
		delay__50us(1);
	}	
}	
/*void display_12864(uchar dat,uchar table[])
{
	uchar i;
	Write_12864com(dat);
	for(i=0;i<16;i++)
	{
		Write_12864dat(table[i]);
		delay__50us(1);
	}	
}	*/

/*void main()
{
	init_12864();
	while(1)
	{
		display_12864(0x80,table1);
		display_12864(0x88,table2);
		while(1);
	}

}	 */