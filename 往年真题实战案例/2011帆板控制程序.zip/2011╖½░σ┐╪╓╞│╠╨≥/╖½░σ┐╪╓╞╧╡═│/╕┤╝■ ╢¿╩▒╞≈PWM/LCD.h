#ifndef __LCD_H__
#define __LCD_H__

#include <reg52.h>
#define uint unsigned int
#define uchar unsigned char 

sbit LCDRS=P2^4;
sbit LCDRW=P2^5;
sbit LCDE=P2^6;



void init();
void write_com(uchar com);
void write_data(uchar dat);
void delay_50us(uchar t);

#endif
