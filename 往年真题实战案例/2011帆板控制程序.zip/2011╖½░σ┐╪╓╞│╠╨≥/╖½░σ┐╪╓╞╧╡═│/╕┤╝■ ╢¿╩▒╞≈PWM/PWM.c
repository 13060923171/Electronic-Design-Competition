
#include < reg52.h > 
#include < intrins.h > 
#include"lcd.h"
#define uint unsigned int
#define uchar unsigned char

 int  pwmx;
char flag;

uchar table1[]="  WWW.GDCP.COM  ";
uchar table2[]="                ";
sbit  K1=P1^0 ;                    //ռ�ձ����Ӽ� 
sbit  K2=P1^1 ;                    //���ټ� 

sbit LED=P3^7;  	  // PWM ���
sbit P2_2=P2^2;            
sbit P2_1=P2^1;
sbit P2_0=P2^0;	  ///***************

//uchar PWM=0xce,f=0x9c ;   //����ֵ 
//  uchar PWM=0x22,f=0x4e ;   //����ֵ 

void delay(uchar t)
{
	while(t--);
}  


void PWMWORK()
{
//	PWM=t;
	//if(PWM>255)
//	PWM=0;

	if(K1==0)
		{		
				delay(10);
				if(K1==0)
				{
					pwmx=pwmx+50;
					while(K1==0);
				}	
		}
		if(K2==0)
		{
				delay(10);
				if(K2==0)
				{		
					pwmx=pwmx-50;
					while(K2==0);
			 	}	
		}	 
	
}
void main ()
{	uchar j ;
/////////////////////////////////////////////////
    pwmx=1000;
	TMOD=0x11;	   //
	TH1=(65536-pwmx)/256;		//
	TL1=(65536-pwmx)%256;		 //

 	TH0=0xFC;		//
	TL0=0x18;

	EA=1;			 //
	ET0=1;
//	ET1=1;
	TR0=1;
//	TR1=1;
	LED=1;
	init();
 //***********************************	
 P2_1=1;
 P2_2=0;

 //*****************************
 P2_0=1;

/////////////////////////////////////////////////
	while(1)
	{
		PWMWORK();			  

		table2[0]=pwmx/100+'0';
		table2[1]=(pwmx%100)/10+'0';
		table2[2]=pwmx%10+'0';
		write_com(0x80); //д��һ��ָ��
			for(j=0;j<16;j++) //д��һ������
			{
				write_data(table1[j]);
				delay_50us(10);
			}		
			write_com(0x80+0x40);//д�ڶ���ָ��
			for(j=0;j<16;j++)	 //д�ڶ�������
			{
				write_data(table2[j]);
				delay_50us(10);
			}	  		

	}
}		
//**************************************************************
void timer0() interrupt 1
{
		//TR0=0;
	if(flag==0)
		   {
                TH0=((65536-2000)+pwmx)/256;   //	TH0=0xfC;		//
            	TL0=((65536-2000)+pwmx)%256;
		    	flag=1;
			}
	else
	     {
		        TH0=(65536-pwmx)/256;   //	TH0=0xfC;		//
            	TL0=(65536+pwmx)%256;
		    	flag=0; 
	     }
		   
	LED=!LED;
}

void timer1() interrupt 3
{
   	//R0=1;		
		TH1=(65536-pwmx)/256;		//
    	TL1=(65536-pwmx)%256;
   //  ET1=0;
//	TR1=0;
	LED=!LED;
}
//********************************************************

