/****************************************Copyright (c)**************************************************

********************************************************************************************************/
#ifndef TRUE
#define TRUE  1
#endif

#ifndef FALSE
#define FALSE 0
#endif


#define uint8    INT8U                    /* Unsigned  8 bit quantity                           */
#define int8     INT8S                    /* Signed    8 bit quantity                           */
#define uint16   INT16U                   /* Unsigned 16 bit quantity                           */
#define int16    INT16S                   /* Signed   16 bit quantity                           */
#define uint32   INT32U                   /* Unsigned 32 bit quantity                           */
#define int32    INT32S                   /* Signed   32 bit quantity                           */


/********************************/
/*      uC/OS-II���������      */
/********************************/

#include "Includes.h"


/********************************/
/*      ARM���������           */
/********************************/

#include    "..\arm\LPC2294.h"


/********************************/
/*     Ӧ�ó�������             */
/********************************/

#include    <stdio.h>
#include    <ctype.h>
#include    <stdlib.h>
#include    <setjmp.h>
#include    <rt_misc.h>


/********************************/
/*     �����ӵ�����             */
/********************************/
/* ϵͳ���� */
#define Fosc            11059200                    //����Ƶ��,10MHz~25MHz��Ӧ����ʵ��һ��
#define Fcclk           (Fosc * 4)                  //ϵͳƵ�ʣ�����ΪFosc��������(1~32)����<=60MHZ
#define Fcco            (Fcclk * 4)                 //CCOƵ�ʣ�����ΪFcclk��2��4��8��16������ΧΪ156MHz~320MHz
#define Fpclk           (Fcclk / 4) * 1             //VPBʱ��Ƶ�ʣ�ֻ��Ϊ(Fcclk / 4)��1��2��4��


#include    "target.h"


// LPC21000 misc uart0 definitions
#define UART0_PCB_PINSEL_CFG     (INT32U)0x00000005
#define UART0_INT_BIT            (INT32U)0x0040
#define LCR_DISABLE_LATCH_ACCESS (INT32U)0x00000000
#define LCR_ENABLE_LATCH_ACCESS  (INT32U)0x00000080
#define LCR_DISABLE_BREAK_TRANS  (INT32U)0x00000000
#define LCR_ODD_PARITY           (INT32U)0x00000000
#define LCR_ENABLE_PARITY        (INT32U)0x00000008
#define LCR_1_STOP_BIT           (INT32U)0x00000000
#define LCR_CHAR_LENGTH_8        (INT32U)0x00000003 
#define LSR_THR_EMPTY            (INT32U)0x00000020

/*********************************************************************************************************
**                            End Of File
********************************************************************************************************/
