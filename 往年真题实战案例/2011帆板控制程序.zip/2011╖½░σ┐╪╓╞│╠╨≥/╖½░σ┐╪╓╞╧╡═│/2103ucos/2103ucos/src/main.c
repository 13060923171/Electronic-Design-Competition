/***********************************************************
	����:�Ƚ���һ��������,��������������������

************************************************************/
#include  "config.h"
//#include  "MOTO.H"


#define LED 0x001e0000    //����P0.17~P0.20
#define   HC595_CS    (1<<7)            /*P0.8��Ϊ74HC595��Ƭѡ*/

//uint16 speed=0;
#define  infrared_right    (1<<11)
#define  infrared_left     (1<<12)


#define uchar unsigned char
#define uint unsigned int

#define clk_0   IO0CLR = 1<<22;
#define clk_1   IO0SET =1<<22;

#define mosi_0 IO0CLR = 1<<23;
#define mosi_1 IO0SET =1<<23;

//#define miso PINB&0X40



#define l_G z_nec(0x00, 0xc0);//��
#define l_B z_nec(0x00, 0xe0);
#define l_S z_nec( 0x00, 0x00);
#define l_pwm(k) z_nec( 0x03, k);


#define r_G z_nec( 0x04, 0xc0);//��
#define r_B z_nec( 0x04, 0xe0);
#define r_S z_nec( 0x04, 0x00);
#define r_pwm(k) z_nec( 0x07, k);

#define res_0 IO0CLR = 1<<25;
#define res_1 IO0SET = 1<<25;


#define  	TASK_STK_SIZE                  64
OS_STK        Main_TaskStk[TASK_STK_SIZE];
OS_STK        Task0Stk[TASK_STK_SIZE];
OS_STK        Task1Stk[TASK_STK_SIZE];
OS_STK        Task2Stk[TASK_STK_SIZE];
OS_STK        Task3Stk[TASK_STK_SIZE];
OS_STK        Task5Stk[TASK_STK_SIZE];

OS_EVENT *LocaBox;
OS_EVENT *lightBox;
OS_EVENT *clogBox;

void  Main_Task(void *data);
void  Task0(void *data);
void  Task1(void *data);
void  Task2(void *data);
void  Task3(void *data);
void  Task5(void *data);


/****************************************************************************
* ���ƣ�main()
* ���ܣ���ʾ�ı�
****************************************************************************/

 int main (void)
{
    OSInit();      
    LocaBox=OSMboxCreate((void*)0);
    lightBox=OSMboxCreate((void*)0);
    clogBox=OSMboxCreate((void*)0);
    
    OSTaskCreate(Main_Task, (void *)0, &Main_TaskStk[TASK_STK_SIZE - 1], 0);
	OSStart();
    return 0;
}
/****************************************************************************
* ���ƣ�Main_Task()
* ���ܣ���ʼ��Ŀ���,������������
****************************************************************************/

 void  Main_Task(void *pdata)
 {
	pdata=pdata;
	TargetInit();
///	OSTaskCreate(Task0, (void *)1, &Task0Stk[TASK_STK_SIZE - 1], 1);
	//OSTaskCreate(Task1, (void *)2, &Task1Stk[TASK_STK_SIZE - 1], 2);	  
   /// OSTaskCreate(Task2, (void *)3, &Task2Stk[TASK_STK_SIZE - 1], 3);
  //  OSTaskCreate(Task3, (void *)4, &Task0Stk[TASK_STK_SIZE - 1], 4);
   OSTaskCreate(Task5, (void *)6, &Task5Stk[TASK_STK_SIZE - 1], 6);
	OSTaskSuspend(OS_PRIO_SELF);
}
/****************************************************************************
* ���ƣ�Task0()
* ���ܣ�Ѱ�ҹ�Դ
****************************************************************************/
void  Task0(void *pdata)
{  
      INT8U   err; 
      INT32U  light;
      
    pdata=pdata;
    
    PINSEL0=PINSEL0&0x30FFFFFF; 
    PINSEL1=PINSEL1&0xFFFFFFF0;
    IODIR=IODIR&((~ (1<<17))&(~(1<<13))&(~(1<<12))&(~(1<<15))&(~(1<<16)));
    
    while(1)
    {
   
         if((IOPIN&0x0003B000)!=0x0003B000)
		    {	  
		          if((IOPIN&0x0003B000)==0x00033000)    //�м䣬ֱ��
		              light=1;		
		          if((IOPIN&0x0003B000)==0x00032000)    //���ң�������
					  light=4; 
				  if((IOPIN&0x0003B000)==0x00023000)    //���󣬿�����
				      light=3;    
				  if((IOPIN&0x0003B000)==0x0003A000)    //�ң�С����
				      light=6;	
				  if((IOPIN&0x0003B000)==0x0002B000)    //��С����
					  light=5;
				  if((IOPIN&0x0003B000)==0x00038000)    //���ң�����
				      light=8;   	
				  if((IOPIN&0x0003B000)==0x0000B000)    //��������
				      light=7;		 	
 				  if((IOPIN&0x0003B000)==0x00039000)    //���ң�������
					  light=10;  
				  if((IOPIN&0x0003B000)==0x0001B000)    //����������
				      light=9;
				        
				        
			      if((IOPIN&0x0003B000)==0x00030000)    //������ ��������
				      light=12;	
				  if((IOPIN&0x0003B000)==0x00003000)    //�����󣬴�����
				      light=11;
				
				
				 
				
			 	
		    }
	    else
		    {
		       light=2;
		     
		    }   
	    
       err=OSMboxPost(lightBox,(void*)&light);
        OSTimeDly(20);
    } 
    
}


/****************************************************************************
* ���ƣ�Task5()
* ���ܣ�����
****************************************************************************/
void  Task5(void *pdata)
{  
     
//uint16 temp2;
//   uint32 *msg;
//   uint32 *clog;
//   uint32 *light;

   
//   uint8 err;
    
 //  Timer1Init();
//   Timer2Init(); 
   
 //  Spi_IO();
 //  MSpiIni();
      
///   LCD_IO();
 ///  lcd_init();   
    
    
    
//   Timer3Init();
//   Motor_IO();
     
 //  pdata=pdata; 
 _delay_us(50);
    // IO0SET =1<<3;
//OSTimeDlyHMSM(0,0,0,5);
//    uint8   uiBuf[30] = {0};
    
 //   PINSEL0 = PINSEL0 & (~0x0F);                                        
 //   PINSEL0 = PINSEL0 | 0x05;                                           /*  ����I/O���ӵ�UART           */

 ///   UARTInit ();                                                        /*  ���ڳ�ʼ��                  */
    
 ///   UART0GetStr(uiBuf, 20);                                             /*  �Ӵ��ڽ����ַ���            */
 //   DelayNS(10);
 ////   UART0SendStr (uiBuf);                                               /*  �򴮿ڷ����ַ���            */
 ///   DelayNS(10);

	init_nec();
	///UARTInit();
    while(1)
	{
///	     UART0SendByte(0xaa);
	
   
   /*(     UART0SendByte(0x50);
         _delay_ms(4);
        UART0SendByte(0xc0);
         _delay_ms(4);
        UART0SendByte(0x53);
          _delay_ms(4);
         UART0SendByte(0x54);
         _delay_ms(4);*/
	l_G;

//	r_G;
	_delay_ms(5);
	
//	l_G;

  //  r_pwm(155);
	l_pwm(45); 


	
//	l_G;
//	r_G;
	//_delay_ms(5);
	
//	l_G;

///  r_pwm(54);
 // l_pwm(30);
	///_delay_ms(3);
	
//	_delay_ms(5);
//	r_G;
//	_delay_ms(5);
//	r_pwm(40);
	     
//if(i>10)i=0;

/*       l_G; _delay_ms(5);l_pwm(5); _delay_ms(5);
       r_G; _delay_ms(5);r_pwm(5);
       _delay_ms(5);
       z_nec_r(0);
	  _delay_ms(500);
	  _delay_ms(500);	_delay_ms(500);	_delay_ms(500);

	  l_B; _delay_ms(5); l_pwm(250); _delay_ms(5);
	  r_B; _delay_ms(5); r_pwm(250);	
	   _delay_ms(5);
	 z_nec_r(0);	
	  _delay_ms(500);
	 _delay_ms(500);	_delay_ms(500);	_delay_ms(500);*/
 






	
	
	
 //   R_dis_speed(T2TC);
//	PID(*light);
//    LCD();
    OSTimeDly(30);
	}
}
