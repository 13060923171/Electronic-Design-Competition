#include  "config.h"
#include  "MOTO.H"

#define L_CP	3				// �������� Proportional Const
#define L_CI	2				// ���ֳ��� Integral Const
#define	L_CD	2						// ΢�ֳ��� Derivative Const

#define R_CP	8					// �������� Proportional Const
#define R_CI	2					// ���ֳ��� Integral Const
#define	R_CD	2					// ΢�ֳ��� Derivative Const

INT8U  nex_msg=0;

INT32U   ticks;
INT32U last_time=0 ; //�ϴ�ʱ��
INT32U now_time;   //����ʱ��
INT16U  sign_time; //��������

INT8U   L_degree=0;     //����
INT32U  L_Sign_Seepd;
INT32U  L_Degree1=0;
INT32U  L_Degree2=0;
INT32U  L_Degree3=0;
INT32U  L_Degree4=0;
INT32U  L_Degree5=0;
INT32U  L_sign_degree;
INT32U  L_average ;  
INT32U  L_distance=0;
INT32U  L_Speed=0;

INT8U   R_degree=0;     //����
INT32U  R_Sign_Seepd;
INT32U  R_Degree1=0;
INT32U  R_Degree2=0;
INT32U  R_Degree3=0;
INT32U  R_Degree4=0;
INT32U  R_Degree5=0;
INT32U  R_sign_degree;
INT32U  R_average ;
INT32U  R_distance=0;
INT32U  R_Speed=0;


#define  metre   24         //����24��
#define  girth   195000;    //�ܳ�19.5cm


//========================================================================
//	�﷨��ʽ��	int DCMotor_Speed_PID(int SetSpeed, int CurSpeed)
//	ʵ�ֹ��ܣ�	����ʽPID����: u0 = u1 + CP*(e0-e1) + CI*e0 + CD*(e0-2*e1+e2)
//	������		SetSpeed:	�趨��ת��
//				CurSpeed:	ʵ�ʲ��ת��
//	����ֵ��	ֱ������ٶȵȼ�(PWMռ�ձ�)
//========================================================================
int L_DCMotor_Speed_PID(INT16U SetSpeed,INT16U CurSpeed)
{
	INT16U e0, u0;
	static INT16U u1 = 0;									// ǰһ�����ֵ
	static INT16U e1 = 0, e2 = 0;

	e0 = SetSpeed - CurSpeed;							// ��ǰ�ٶ�ƫ��
	u0 = u1											
		 + L_CP * (e0 - e1)								// ������
		 + L_CI * e0										// ������
		 + L_CD * (e0 - e1 - e1 + e2);					// ΢����
	R_dis_speed(u0);
    setL_dutyfactor(u0);
	u1 = u0;											// ����u1��e1��e2
	e2 = e1;
	e1 = e0;
	                             
	return u0;										// ����u0
}


int R_DCMotor_Speed_PID(INT16U SetSpeed,INT16U CurSpeed)
{
	INT16U e0, u0;
	static INT16U u1 = 0;									// ǰһ�����ֵ
	static INT16U e1 = 0, e2 = 0;

	e0 = SetSpeed - CurSpeed;							// ��ǰ�ٶ�ƫ��
	u0 = u1											
		 + R_CP * (e0 - e1)								// ������
		 + R_CI * e0;										// ������
		 + R_CD * (e0 - e1 - e1 + e2);					// ΢����
    L_dis_speed(u0);
    setR_dutyfactor(u0);
	u1 = u0;											// ����u1��e1��e2
	e2 = e1;
	e1 = e0;
	                             
	return u0;										// ����u0
}



R_dis_speed(uint32 dis)
{	
	WrOp(0x81);		
	w_num(dis);
	WrDat('c');	
    WrDat('m');
    WrDat('/');	
    WrDat('s');
    
 }   
 
 L_dis_speed(uint32 dis)
{	
	WrOp(0x8A);		
	w_num(dis);
	WrDat('m');	
    WrDat('m');
    WrDat('/');	
    WrDat('s');
    
 }  
INT16U DPL(void)
{
      L_degree++;
      switch(L_degree)
            {
              
                case 1:
                       L_Degree1=T1TC;
                       
                break;
                
                case 2:
                       L_Degree2=T1TC;
                         
                break;                                                                                                                                                                                                                                                       
                case 3:
                       L_Degree3=T1TC; 
                       L_average=(L_Degree3+L_Degree2+L_Degree1)*10/3; 
                       L_distance=L_average*2306;
                       L_Speed=L_distance*10/sign_time;               
                       L_Speed=L_Speed/10000;                        
                       L_Degree1=L_Degree2;
                       L_Degree2=L_Degree3;
  
                                   
                       L_degree=2; 
                break;
            
              
            
            }           
     T1TC=0;  
    
     return(L_Speed);
}


INT16U DPR(void)
{
      R_degree++;
      switch(R_degree)
            {
 
              
                case 1:
                       R_Degree1=T2TC;
                       
                break;
                
                case 2:
                       R_Degree2=T2TC;
                         
                break;                                                                                                                                                                                                                                                       
                case 3:
                       R_Degree3=T2TC; 
                       R_average=(R_Degree3+R_Degree2+R_Degree1)*10/3; 
                       R_distance=R_average*2306;
                       R_Speed=R_distance*10/sign_time;               
                       R_Speed=R_Speed/10000; 
                                               
                       R_Degree1=R_Degree2;
                       R_Degree2=R_Degree3;
   
                                   
                       R_degree=2; 
                break;
            
              
            
            }           
    T2TC=0;  
    
     return(R_Speed);
}


int PID(int msg)
{
    switch(msg)
		 {  


            case  0:      //ֹͣ
                          Control_L_Stop();
			              Control_R_Stop();
			break;
            case 1:       //��ֱ��
                             
                        R=25;
                        L=25;                  
				        Control_L_Positive();        
			            Control_R_Positive();            
			break;
            case 2:       //��ֱ��
                             
                        R=20;
                        L=20;                  
				        Control_L_Positive();        
			            Control_R_Positive();            
			break;   
			case 3: 	
			            //����ת
			            R=25;
			            L=20;
			            Control_L_Positive();
			            Control_R_Positive();	
			break;
		    case 4:       //����ת
					    R=20;
			            L=25;                  
				        Control_L_Positive(); 
			            Control_R_Positive();    
			break;
			case 5:       //С��ת
					    R=25;
			            L=7;                  
				        Control_L_Positive(); 
			            Control_R_Positive();    
			break;
			case 6:       //С��ת
					    R=7;
			            L=25;                  
				        Control_L_Positive(); 
			            Control_R_Positive();    
			break;
		    case 7:       //��ת
					    R=20;
			            L=7;                  
				        Control_L_Reverse(); 
			            Control_R_Positive();    
			break;
		    case 8:       //��ת
					    R=7;
			            L=20;                  
				        Control_L_Positive(); 	
			            Control_R_Reverse();    
			break;
		    case 9:       //����ת
					    R=20;
			            L=10;                  
				        Control_L_Reverse(); 
			            Control_R_Positive();    
			break;
			case 10:       //����ת
					    R=10;
			            L=20;                  
				        Control_L_Positive(); 
			            Control_R_Reverse();    
			break;
			
		
		
			
            case 11:       //����ת
					    R=22;
			            L=20;                  
				        Control_L_Reverse(); 
			            Control_R_Positive();    
			break;
            case 12:       //����ת
					    R=20;
			            L=22;                  
				        Control_L_Positive(); 
			            Control_R_Reverse();    
			break;
			
			
			
			
            case 13:       //����ת
					    R=20;
			            L=1;                  
				        Control_L_Positive(); 
			            Control_R_Positive();    
			break;
		    case 14:       //����ת
					    R=1;
			            L=20;                  
				        Control_L_Positive(); 
			            Control_R_Positive();    
			break;
			case 15:       //ֱ��ת
					    R=20;
			            L=5;                  
				        Control_L_Positive(); 
			            Control_R_Positive();    
			break;
			case 16:       //ֱ��ת
					    R=5;
			            L=20;                  
				        Control_L_Positive(); 
			            Control_R_Positive();    
			break;
		 } 
       
         now_time=OSTimeGet()/1;
	     sign_time=now_time-last_time;
	     
	     if(sign_time>=10) 	
	      {
	           L_Sign_Seepd=DPL();
	           L_DCMotor_Speed_PID(L,L_Sign_Seepd); 
	        ///   L_dis_speed(L_Sign_Seepd);
	           
	           R_Sign_Seepd=DPR();
	           R_DCMotor_Speed_PID(R,R_Sign_Seepd); 
	         ///  R_dis_speed(R_Sign_Seepd);
	         
	           last_time=now_time;
          }
    


     


}