#include  "config.h"

#define rs (1<<8)
#define rw (1<<9)
#define en (1<<5)
//#define busy (1<<5)
//#define   HC595_CS    (1<<10)            /*P0.8��Ϊ74HC595��Ƭѡ*/
uint32 speed=0;
uint8 txt[]={"Distance:"};
uint8 txt1[]={"Time:"};

 INT32U    read_ticks;
 



void delay(uint16 n)
{
	while(n--) ;
}
void LCD_IO(void)
{

    PINSEL0=PINSEL0 & 0XFFC0F3FF;
    
    IODIR=IODIR|rs|rw|en;

}
/****************************************************************************
* ���ƣ�ChkBusy()
* ���ܣ���������Ƿ�æ
****************************************************************************
void ChkBusy()
{
	//PINSEL0=0xffc00000;
  //  PINSEL0=0x00000000;
      IODIR=IODIR&(~busy);
 //   IODIR=IO0DIR&(~busy);
	while(1)
	{
		IOCLR=rs;
		IOSET=rw;
		IOSET=en;
		if(!(IOPIN & busy)) break;
		IOCLR=en;
	}
	IODIR=IODIR|busy;
	// IODIR=IO0DIR|busy;
//	IODIR=IODIR|0x7ff;
}
/****************************************************************************
* ���ƣ�WrOp()
* ���ܣ�д����
****************************************************************************/
void WrOp(uint8 dat)
{
	
 //   ChkBusy();
	IOCLR=rs;		//ȫ������
	IOCLR=rw;
//	IOCLR=0xff;		//������
     MSendData(0XFF);
//	IOSET=dat;		//������
	 MSendData(dat);
	IOSET=en;	
	IOCLR=en; 
	delay(200);	
}
/****************************************************************************
* ���ƣ�WrDat()
* ���ܣ�д���ݺ���
****************************************************************************/
void WrDat(uint8 dat)	//������
{
   
//	ChkBusy();
	IOSET=rs;
	IOCLR=rw;
//	IOCLR=0xff;		//������
	  MSendData(0XFF);
//	IOSET=dat;		//������
	    MSendData(dat);
	IOSET=en;	
	IOCLR=en;
	delay(120);		
}
/****************************************************************************
* ���ƣ�lcd_init()
* ���ܣ�lcd��ʼ������
****************************************************************************/
void lcd_init(void)
{

	WrOp(0x38);			
	WrOp(0x06);			//����1
	WrOp(0x0c);			//����ʾ
	WrOp(0x01);			//����
}

/****************************************************************************
* ���ƣ�DisText()
* ���ܣ���ʾ�ı�����
****************************************************************************/

void DisplayText(uint8 addr,uint8 *p)
{
	WrOp(addr);
	while(*p !='\0') WrDat(*(p++));
	
}

void  __irq Timer0ISR (void)
{

  WrDat(':');
}


void w_num(uint16 num)
{
	uint16 num0;	
	if(num0=num/100)	 //��0����ʾ
	{
		WrDat(num0+0x30);		
		num0=(num%100/10);
		WrDat(num0+0x30);
	}
	else
    {
		//WrDat(' ');		
		if(num0=(num%100/10)) WrDat(num0+0x30);
		//else			  WrDat(' ');
	}	
	num0=num%10;
	WrDat(num0+0x30);	
}




  
	
/*if(dis/10000<100) 
	{
	  w_num(dis/10000);
	  WrDat('c');	
	  WrDat('m');
	}	
	else 
	{
	 w_num(dis/10000/10);
	 WrDat('.');
	 w_num(dis/10000%10);
	 WrDat('d');	
	 WrDat('m'); 
	} *
	if((dis/10000)<100) w_num(dis/10000);
	else    
	{  
	   w_num(dis/10000/10);
	   	WrDat('.');	
	   w_num(dis/10000%10);	
	}
	//WrDat('r');   				//��ʾr/min
	//WrDat('/');	
	if((dis/10000)<100)
	{		
		WrDat('c');		
		WrDat('m');		
		//WrDat('n');
		
	}
	else               //r/min
	{
	    WrDat('d');		
		WrDat('m');	
		//WrDat('s');		
    }	*/



void LCD(void)
{  

       // DisplayText(0x80,txt);
       // DisplayText(0xc0,txt1);
	    read_ticks=OSTimeGet()/OS_TICKS_PER_SEC;
	  
   		WrOp(0xc8);				
		WrDat(read_ticks/3600/10+0x30);
		WrDat(read_ticks/3600%10+0x30);
		WrDat(':');
		WrDat(read_ticks%3600/60/10+0x30);
		WrDat(read_ticks%3600/60%10+0x30);
	   
		WrDat(':');
		WrDat(read_ticks%60/10+0x30);
	    WrDat(read_ticks%60%10+0x30);
	    
	   	

}

