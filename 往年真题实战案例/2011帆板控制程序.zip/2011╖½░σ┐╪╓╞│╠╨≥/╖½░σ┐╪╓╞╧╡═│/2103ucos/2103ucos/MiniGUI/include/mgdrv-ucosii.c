//====================================================================
// File Name : mgdrv-ucosii.c
//====================================================================

/* ����MiniGUI������ͷ�ļ�(��������ѡ��) */
#include "MiniGUI_config.h"

/* ����MiniGUIͷ�ļ� */
#include "common.h"
#include "minigui.h"
#include "gdi.h"
#include "window.h"
#include "control.h"

/* ע�⣬Ҫ��������SWAP_XY_EN������������������ */
#define  GUI_LCM_XMAX		320							/* ����Һ��x��ĵ��� */
#define  GUI_LCM_YMAX		240							/* ����Һ��y��ĵ��� */


#define IAL_MOUSE_LEFTBUTTON    4
#define IAL_MOUSE_MIDDLEBUTTON  2
#define IAL_MOUSE_RIGHTBUTTON   1

#define IO1PIN          (*((volatile unsigned long *) 0xE0028010)) 

extern  void  OSTimeDly(WORD ticks);


// ����������P1��
#define  KEY_TAB		(1<<23)
#define  KEY_ENTER		(1<<21)
#define  KEY_UP			(1<<20)
#define  KEY_DOWN		(1<<19)
#define  KEY_LEFT		(1<<18)
#define  KEY_RIGHT		(1<<22)
#define  KEY_ALL		(KEY_TAB | KEY_ENTER | KEY_UP | KEY_DOWN | KEY_LEFT | KEY_RIGHT)

	
/* --------------------- For Common IAL Engine ----------------- */
/* Should be implemented if you use common ial engine in MiniGUI */

#define COMM_MOUSEINPUT    0x01  /* ���������¼� */
#define COMM_KBINPUT       0x02  /* �����¼� */

/*
 * Waits for input for keyboard and touchpanel. 
 * If no data, this function should go into sleep;
 * when data is available, keyboard or touchpanel driver should wake up
 * the task/thread in MiniGUI who call comm_wait_for_input.
 *
 * Normal implementation make this function sleep on a ucosii semaphore.
 * return COMM_MOUSEINPUT or COMM_KBINPUT according to type of the input event.
 */
 // ��ѯ���̻�����¼�
 
 static  unsigned char  key_sta=0;
 
/*
int comm_wait_for_input (void)
{	int  i;
    
	// ɨ�谴�������а����򷵻ذ����¼�
	for(i=0; i<100; i++)
	{	if((IO1PIN&KEY_ALL) != KEY_ALL)
		{	OSTimeDly(2);					// ��ʱ10mS��ȥ��
			if((IO1PIN&KEY_ALL) != KEY_ALL)
			{	key_sta = 1;
				return(COMM_KBINPUT);		// ȷ���а�������
			}
		}
	}
	
	if(key_sta==1)
	{	key_sta=0;
		return(COMM_KBINPUT); // �а����ſ�
	}
	
    OSTimeDly(20); // û���ⲿ�¼�����ʱ100mS����ÿ100mSɨ��һ�ΰ���
    
    return 0;
}
*/

static  unsigned char  mouse_sta=0;

int comm_wait_for_input (void)
{	int  i;
    
	// ɨ�谴�������а����򷵻�����¼�
	for(i=0; i<100; i++)
	{	if((IO1PIN&KEY_ALL) != KEY_ALL)
		{	OSTimeDly(2);					// ��ʱ10mS��ȥ��
			if((IO1PIN&KEY_ALL) != KEY_ALL)
			{	return(COMM_MOUSEINPUT);	
			}
		}
	}
	
	if(mouse_sta==1)
	{	mouse_sta=0;
		return(COMM_MOUSEINPUT); // �а����ſ�
	}
	
    OSTimeDly(20); // û���ⲿ�¼�����ʱ100mS����ÿ100mSɨ��һ�ΰ���
    
    return 0;
}

/*
 * Gets touchpanel position and button data.
 * x, y   : position values
 * button : Non-zero value means pen is down.
 */
 
 // �ú����ķ���ֵ������IAL_MOUSE_LEFTBUTTON(��ʾ�������)��
// IAL_MOUSE_MIDDLEBUTTON(��ʾ�м�����)��IAL_MOUSE_RIGHTBUTTON
// (��ʾ�Ҽ�����)��ֵ"��"�Ľ����
 // ȡ�����/�������Ĳ���
int comm_ts_getdata (int *x, int *y, int *button)
{	unsigned long  io_dat;

	io_dat = IO1PIN;			// ɨ�谴����Ȼ�󷵻�
	if((io_dat&KEY_DOWN) == 0)
	{	*y = (*y) + 5;
	    if((*y) > (GUI_LCM_YMAX-1))
	    {	*y = GUI_LCM_YMAX - 1;
	    }
		return(0);
	}
	if((io_dat&KEY_UP) == 0)
	{	*y = (*y) - 5;
		if((*y) < 0)
		{	*y = 0;
		}
		return(0);
	}
	if((io_dat&KEY_RIGHT) == 0)
	{	*x = (*x) + 5;
		if((*x) > (GUI_LCM_XMAX-1))
		{	*x = GUI_LCM_XMAX-1;
		}
		return(0);
	}
	if((io_dat&KEY_LEFT) == 0)
	{	*x = (*x) - 5;
		if((*x) < 0)
		{	*x = 0;
		}
		return(0);
	}
	
	if((io_dat&KEY_ENTER) == 0)
	{	mouse_sta = 1;
		*button = IAL_MOUSE_LEFTBUTTON;
		return(0);
	}
	
	if((io_dat&KEY_TAB) == 0)
	{	mouse_sta = 1;
		*button = IAL_MOUSE_RIGHTBUTTON;
		return(0);
	}
	
	if(mouse_sta==0)
	{	*button = 0;
		return(0);
	}
    
    return(-1);
}

/*
 * Gets keyboard key data.
 * key        : return MiniGUI scancode of the key.
 * key_status : key down or up, non-zero value means down.
 */
  // ȡ�ð����Ĳ���
int comm_kb_getdata (short *key, short *key_status)
{	unsigned long  io_dat;
	
	
	if(key_sta==1)
	{	io_dat = IO1PIN;			// ɨ�谴����Ȼ�󷵻�
		if((io_dat&KEY_TAB) == 0)
		{	*key = SCANCODE_TAB;
			*key_status = 1;
			return(0);
		}
	
		if((io_dat&KEY_ENTER) == 0)
		{	*key = SCANCODE_ENTER;
			*key_status = 1;
			return(0);
		}
    }
    else
    {	*key_status = 0;			// �����ſ�
		return(0);
    }
    
    return(-1);
}

/* --------------------- I/O functions -------------------------- */
// for debug purpose

/* Gets a char from uart */
BYTE drv_uart_get_byte (void)
{
    //...
    return(0);
}

/* Sends a char to uart */
void drv_uart_send_byte (BYTE ch)
{
    //...
}

/* ----------------- Implementation of MiniGUI LCD driver interface --------------- */

#define FB_TYPE_RGB565    1  // RGB565 color format for 16 bpp
#define FB_TYPE_RGB332    2  // RGB332 color format for 8 bpp

struct lcd_info {
    short height, width;  // Pixels
    short bpp;            // Depth (bits/pixel)
    short type;           // pixel type
    short rlen;           // Length of one raster line in bytes
    void  *fb;            // Frame buffer
};

int drv_lcd_init (void)
{
    /* Do LCD initialization here, if you have not. */ 
    return 0;
}

int drv_lcd_getinfo (struct lcd_info *li)
{
    /* 
     * Set LCD information in a lcd_info structure pointed by li
     * according to properties of your LCD.
     */
/*     
	li->width  = 320;
	li->height = 240;
	li->bpp    = 16;
	li->type   = FB_TYPE_RGB565;
	li->rlen   = 320;
	li->fb     = (void*)0xc000000;
*/	

    return 0;
}

/* ------------------- Application entry for uC/OS-II -------------- */
/* for reference only */

/*
 * main task of MiniGUI
 */
 

static void* mg_main_task (void* args)
{
    /*
     * Enter entry in MiniGUI library
     */
    minigui_entry (0, NULL);

    while(1)
    {  OSTimeDly (50);
    }
    
    return NULL;
}

/*
 * MiniGUI entry for uC/OS-II
 * You can call this function before you call OSStart.
 */
void minigui_app_entry (void)
{
    pthread_t main_thread;

    /*
     * Should initialize heap memory management module first
     * before using MiniGUI.
     */
    if (ucos2_malloc_init ()) {
        fprintf (stderr, "Can not init our own malloc implementation for uC/OS-II.\n");
        return;
    }
    /*
     * Should initialize POSIX thread module first
     * before using MiniGUI.
     */
    if (ucos2_posix_pthread_init ()) {
        fprintf (stderr, "Can not init our own pthread implementation for uC/OS-II.\n");
        return;
    }

    /*
     * Creating a independent thread for MiniGUI main task is a good idea.
     */
	pthread_create (&main_thread, NULL, mg_main_task, NULL);
}

