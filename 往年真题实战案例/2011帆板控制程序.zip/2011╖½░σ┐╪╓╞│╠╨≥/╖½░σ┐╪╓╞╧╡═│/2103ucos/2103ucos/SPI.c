#include  "config.h"

#define   MSTR        (1<<5)
#define   CPOL        (1<<4)
#define   CPHA        (1<<3)
#define   LSBF        (1<<6)
#define   SPI_MODE    (MSTR|CPOL )
#define   HC595_CS    (1<<7)            /*P0.8��Ϊ74HC595��Ƭѡ*/

uint8 dat;
/*******************************************************************************
*����: DelayNS()
*����: ��������ʱ
*******************************************************************************/
void _delay_us(uint32 dly)
{  uint32  i;
   for (;dly>0;dly--)
      for(i=0;i<80;i++);
}

void _delay_ms(uint32 dly)
{  uint32  i;
   for (;dly>0;dly--)
      for(i=0;i<80000;i++);
}
/*******************************************************************************
*����: Spi_IO()
*����: ��ʼ��SPI�ӿ�
*******************************************************************************/
void Spi_IO(void)
{
         PINSEL0  = (PINSEL0 & (~(0x03 << 8))) | (0x01 << 8);
         PINSEL0  = (PINSEL0 & (~(0x03 << 12))) | (0x01 << 12);  
         PINSEL0  = (PINSEL0 & (~(0x03 << 10))) | (0x01 << 10); 
         PINSEL0=PINSEL0&0xFFFF3FFF;  
         IODIR=HC595_CS; 

}
/*******************************************************************************
*����: MSpiIni()
*����: ��ʼ��SPI�ӿ�,����Ϊ����
*******************************************************************************/
void MSpiIni(void)
{ SPI_SPCCR=0xB2;           //����SPIʱ�ӷ�Ƶ
  SPI_SPCR=SPI_MODE;        //����SPI�ӿ�ģʽ,MSTR=1,CPOL=1,CPHA=0,LSBF=0
 
}
/*******************************************************************************
*����: MSendData()
*����: ��SPI���߷�������
*******************************************************************************/
uint8 MSendData(uint8 data)
{
   dat=data;

// IOCLR=HC595_CS;  
                           //Ƭѡ
  SPI_SPDR=data;
  while(0==(SPI_SPSR&0x80));                  //�ȴ�SPIF��λ,���ȴ����ݷ������
 
//  IOSET=HC595_CS;
  return(SPI_SPDR);
}


uint8 MSPIRcvByte (void)
{
	while ((SPI_SPSR & 0x80) == 0);                          /*  �ȴ����ݽ������  */ 
	
	return (SPI_SPDR);
}


#define uchar unsigned char
#define uint unsigned int

#define clk_0   IO0CLR = 1<<22;
#define clk_1   IO0SET =1<<22;

#define mosi_0 IO0CLR = 1<<23;
#define mosi_1 IO0SET =1<<23;

#define miso IOPIN&0X01000000



#define l_G z_nec(0x00, 0xc0);//��
#define l_B z_nec(0x00, 0xe0);
#define l_S z_nec( 0x00, 0x00);
#define l_pwm(k) z_nec( 0x03, k);


#define r_G z_nec( 0x04, 0xc0);//��
#define r_B z_nec( 0x04, 0xe0);
#define r_S z_nec( 0x04, 0x00);
#define r_pwm(k) z_nec( 0x07, k);

#define res_0 IO0CLR = 1<<25;
#define res_1 IO0SET = 1<<25;



void init_nec()
{      


     PINSEL1=PINSEL1&0XFFF00FFF;
     IO0DIR=IO0DIR|0X03C00000;

	///DDRB=(1<<3)|(1<<4)|(1<<5)|(1<<7);//�����õ��ĸ�������Ϊ�����
	res_0;
	_delay_ms(2);
	res_1;
	_delay_ms(2);
	//SPCR=(1<<SPE)|(1<<MSTR)|(1<<SPR0)|(0<<CPOL)|(0<<CPHA);//spiͨѶ��ʼ��
	

}
uchar write_nec(uchar data)
  {
    uchar i;
    clk_0;
 for(i=0;i<8;i++)
  {
     _delay_us(2);
     if(data&0x80)mosi_1
       else mosi_0;
    	data<<=1;if(miso)data++;
    	 _delay_us(2);
         clk_1;
         _delay_us(2);
         clk_0;
         _delay_us(2);
   }	
   _delay_ms(10);
   return (data);
  }


uchar z_nec_r(uchar add)//д��ַʱ ����λΪ5
{

	uchar data;
	add+=0xA0;
	write_nec(add);
	data=write_nec(add);
	_delay_ms(10);
		
	return (data);					
}

void z_nec(uchar add,uchar data)//д��ַʱ ����λΪ5
{

	add+=0x50;
	write_nec(add);
	write_nec(data);_delay_ms(10);	

}