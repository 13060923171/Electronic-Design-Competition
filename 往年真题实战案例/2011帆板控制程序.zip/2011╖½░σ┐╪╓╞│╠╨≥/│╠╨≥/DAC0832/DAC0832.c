#include<reg52.h>
#define uint unsigned int
#define uchar unsigned char 

sbit WR1=P3^0;
sbit CS=P3^1;
void delay_50US(uint t)
{
	uchar j;
	for(;t>0;t--)
		for(j=19;j>0;j--) ;
}
main()
{
	uchar a=0;
	WR1=0;
	CS=0;
	while(1)
	{
		P1=a;
		a++;
		delay_50US(1000);
	}
}