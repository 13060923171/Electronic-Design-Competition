#include <reg52.h>
#define uint unsigned int
#define uchar unsigned char

 unsigned char code ziku[]=	{0xc0,0xf9,0xa4,0xb0,0x99, //0,1,2,3,4, 
							0x92,0x82,0xD8,0x80,0x90, //5,6,7,8,9,
							0x88,0x83,0xc6,0xa1,0x86, //A,B,C,D,E
							0x8e //F
							};
void delay(uint t)
{
	uint a,b;
	for(a=0;a<t;a++)
	for(b=0;b<255;b++);
}
void main()
{
	uchar i;
	while(1)
	{					 
		for(i=0;i<8;i++)
		{
			P2=i;
			P0=~ziku[i];
			delay(1);	   //��̬��ʾ����
			//delay(500);		  //��̬��ʾ���
		}
	}
}

