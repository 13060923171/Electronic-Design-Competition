#include <reg52.h>
#define uint unsigned int
#define uchar unsigned char 

unsigned  code number[]= {  0xc0,0xf9,0xa4,0xb0,0x99, //0,1,2,3,4, 
							0x92,0x82,0xD8,0x80,0x90, //5,6,7,8,9,
							0x88,0x83,0xc6,0xa1,0x86, //A,B,C,D,E
							0x8e };	   //F

void delay_50us(uchar t)
{
	uchar j;
	for(;t>0;t--)
	for(j=19;j>0;j--);
}

void main()
{	
	uchar key;
	while(1)
	{
//*************************************	0~3		   
	P3=0xfe;
	key=P3;
	key=key&0xf0;
	if(key!=0xf0)
	{
		delay_50us(200);
		if(key!=0xf0)
		{
		switch (key)
		{	 case 0x70: P0=~number[0];	break;	  	   //��ͬ�����Ĵ��벻һ����Ҫ��ʵ�ʵ�·�Ľӷ�
			case 0xb0: P0=~number[1];	break;
			case 0xd0: P0=~number[2];	break;
			case 0xe0: P0=~number[3];	break;
		}	
		}
	}

//************************************************ 4~7
	P3=0xfd;
	key=P3;
	key=key&0xf0;
	if(key!=0xf0)
	{
		delay_50us(200);
		if(key!=0xf0)
		{
		switch (key)
		{	 case 0x70: P0=~number[4];	break;	  	   //��ͬ�����Ĵ��벻һ����Ҫ��ʵ�ʵ�·�Ľӷ�
			case 0xb0: P0=~number[5];	break;
			case 0xd0: P0=~number[6];	break;
			case 0xe0: P0=~number[7];	break;
		}	
		}
	}

//**************************************************   8~11
	P3=0xfb;
	key=P3;
	key=key&0xf0;
	if(key!=0xf0)
	{
		delay_50us(200);
		if(key!=0xf0)
		{
		switch (key)
		{	 case 0x70: P0=~number[8];	break;	  	   //��ͬ�����Ĵ��벻һ����Ҫ��ʵ�ʵ�·�Ľӷ�
			case 0xb0: P0=~number[9];	break;
			case 0xd0: P0=~number[10];	break;
			case 0xe0: P0=~number[11];	break;
		}	
		}
	}

//*************************************************	12~15
	P3=0xf7;
	key=P3;
	key=key&0xf0;
	if(key!=0xf0)
	{
		delay_50us(200);
		if(key!=0xf0)
		{
		switch (key)
		{	 case 0x70: P0=~number[12];	break;	  	   //��ͬ�����Ĵ��벻һ����Ҫ��ʵ�ʵ�·�Ľӷ�
			case 0xb0: P0=~number[13];	break;
			case 0xd0: P0=~number[14];	break;
			case 0xe0: P0=~number[15];	break;
		}	
		}
	}

	}	
}