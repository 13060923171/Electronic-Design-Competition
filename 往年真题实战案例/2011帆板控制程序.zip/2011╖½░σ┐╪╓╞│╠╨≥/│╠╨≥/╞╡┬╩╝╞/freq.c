#include<reg52.h>
#include"lcd.h"
#define uchar unsigned char 
#define uint unsigned int

sbit K=P1^0;
uchar table1[]="  WWW.GDCP.COM  ";
uchar table2[]="Frequency     HZ";
uchar Count=0;

void delay (uchar x)
{
	uchar i;
	while(x--)
		for(i=0;i<120;i++);
}
void main()
{
	
	uchar j;
	init();
	IE=0x8A;	//������ʱT0��T1�ж�
	TMOD=0x51;	//T1Ϊ16λ��������T0Ϊ16λ��ʱ��
	TH0=(65536-50000)/256;
	TL0=(65536-50000)%256;
	while(1)
	{
		if(K==0)
		{
			delay(10);
			if(K==0)
			{
				TR1=TR0=1;
			}
		}
			write_com(0x80); //д��һ��ָ��
			for(j=0;j<16;j++) //д��һ������
			{
				write_data(table1[j]);
				delay_50us(10);
			}		
			write_com(0x80+0x40);//д�ڶ���ָ��
			for(j=0;j<16;j++)	 //д�ڶ�������
			{
				write_data(table2[j]);
				delay_50us(10);
			}	  		
	}	
}

void INT_T0() interrupt 1
{
	uint Tmp;
	TH0=(65536-50000)/256;
	TL0=(65535-50000)%256;
	if(++Count==20)
	{
	 //	TR1=TR0=0;
		Count=0;
		Tmp=TH1*256+TL1;
		table2[9]=Tmp/10000+'0';
		table2[10]=(Tmp%10000)/1000+'0';
		table2[11]=(Tmp%1000)/100+'0';
		table2[12]=(Tmp%100)/10+'0';
		table2[13]=Tmp%10+'0';
		Tmp=0;
		TH1=0;
		TL1=0;
		TR1=TR0=0;		 /////////////
		TR1=TR0=1;		/////////////////////
	}
	
}