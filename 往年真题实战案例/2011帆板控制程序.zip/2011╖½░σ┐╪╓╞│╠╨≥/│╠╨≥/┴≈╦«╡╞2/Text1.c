#include <reg52.h>
#define uint unsigned int
#define uchar unsigned char

void delay(uchar t)
{
	uchar a,b;
	for(a=0;a<t;a++)
	for(b=0;b<200;b++);
}

void main()
{
	uchar k,i;
	while(1)
	{
	    k=0xfe;
		for(i=0;i<8;i++)
		{
			P1=k;
			delay(200);
		    k=k<<1;			   
		    k=k|0x01;
		};
	}
}