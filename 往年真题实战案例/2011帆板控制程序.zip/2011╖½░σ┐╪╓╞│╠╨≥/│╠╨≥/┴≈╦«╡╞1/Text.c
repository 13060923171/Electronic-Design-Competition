#include <reg52.h>
#include <intrins.h>
#define uint unsigned int
#define uchar unsigned char


void delay(uchar t)
{
	uchar a,b;
	for(a=0;a<t;a++)
	for(b=0;b<200;b++);	
}
void main()
{
	char i,LED;
	while(1)
	{
		LED=0xfe;
		for(i=0;i<8;i++)
		{
			
			P1=LED;
			delay(200);
			LED=_crol_ (LED,1);//�ÿ⺯����λ
		};
	}; 

}
	