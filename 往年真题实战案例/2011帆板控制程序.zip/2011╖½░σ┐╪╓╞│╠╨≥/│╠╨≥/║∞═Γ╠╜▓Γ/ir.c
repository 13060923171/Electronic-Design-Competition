#include <reg52.h>
#define uint unsigend int
#define uchar unsigned char

sbit ir_led=P3^3;										 
sbit ir_rece=P3^2;
sbit a=P1^5;

void delay_50us(uchar t)
{
	uchar j;
	for(;t>0;t--)
	for(j=19;j>0;j--);
}

 
void main()
{

	   while(1)
	   {
		ir_led=0;
		ir_rece=1;

		if(ir_rece==0)
		a=0;
		delay_50us(100);
		a=1	;
	   }
	

																  
}