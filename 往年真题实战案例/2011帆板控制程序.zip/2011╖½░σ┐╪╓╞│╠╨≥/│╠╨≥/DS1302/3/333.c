#include <reg52.h>
#include <intrins.h>
#include <string.h>

#define uint unsigned int
#define uchar unsigned char 

sbit IO=P3^4;
sbit CLK=P3^6;
sbit RST=P3^5;
sbit LCDRS=P2^4;
sbit LCDRW=P2^5;
sbit LCDE=P2^6;

uchar *WEEK[]={"SUN","***","MON","TUS","WEN","THU","FRI","SAT"};
uchar table1[]="DATA 00-00-00   ";
uchar table2[]="TIME 00:00:00   ";
uchar DateTime[7];
void DelayMS(uint x)
{
	uchar j;
	while(x--)for(j=0;j<120;j++);
}
//��DS1302д��һ�ֽ�
void Writr_A_Byte(uchar x)
{
	uchar i;
	for(i=0;i<8;i++)
	{
		IO=x&0x01;CLK=1;CLK=0;x>>=1;
	}
}
//��DS1302��ȡһ�ֽ�
uchar Get_A_Byte()
{
	uchar i,b=0x00;
	for(i=0;i<8;i++)
	{
		b|=_crol_((uchar)IO,i);
		CLK=1;CLK=0;
	}
	//BCD��ת��
	return b/16*10+b%16;
}
//��DS1302ָ��λ�ö�����
uchar Read_Data(uchar addr)
{
	uchar dat;
	RST=0;CLK=0;RST=1;
	Writr_A_Byte(addr);
	dat=Get_A_Byte();
	CLK=1;RST=0;
	return dat;
}

/*//��DS1302ĳ��ַд������
void Write_DS1302(uchar addr,uchar dat)
{
	CLK=0; RST=1;
	Writr_A_Byte(addr);
	Writr_A_Byte(dat);
	CLK=0; RST=0;
} */


//��ȡ��ǰʱ�䣨�롢�֡�ʱ��
void GetTime()
{
	uchar i,addr=0x81;
	for(i=0;i<7;i++)
	{
		DateTime[i]=Read_Data(addr)	;addr+=2;				
	}
}


void delay_50us(uchar t)
{
	uchar j;
	for(;t>0;t--)
	for(j=19;j>0;j--);
}
//дָ��
void write_com(uchar com)
{
	LCDE=0;
	LCDRS=0;
	LCDRW=0;
	P0=com;
	delay_50us(10);
	LCDE=1;
	delay_50us(20);
	LCDE=0;
}
//д����
void write_data(uchar dat)
{
	LCDE=0;
	LCDRS=1;
	LCDRW=0;
	P0=dat;
	delay_50us(10);
	LCDE=1;
	delay_50us(20);
	LCDE=0;	
}
//��ʼ��
void init()
{
	delay_50us(30);
	write_com(0x38);
	delay_50us(100);
	write_com(0x38);
	delay_50us(100);
    write_com(0x38);
	write_com(0x38);
	write_com(0x08);
	write_com(0x01);
	write_com(0x06);
	write_com(0x0c);

}



//������ʱ��ֵת��Ϊ�����ַ�
void Format_DateTime(uchar d,uchar *a)
{
	a[0]=d/10+'0';
	a[1]=d%10+'0';
}

void main()
{
	
	uchar j;
	init();
	while(1)
	{
		GetTime();

		//������
		Format_DateTime(DateTime[6],table1+5);
		Format_DateTime(DateTime[4],table1+8) ;
		Format_DateTime(DateTime[3],table1+11);
		//����

		strcpy(table1+13,WEEK[DateTime[5]]);
		//ʱ����
		Format_DateTime(DateTime[2],table2+5);
		Format_DateTime(DateTime[1],table2+8) ;
		Format_DateTime(DateTime[0],table2+11);

		write_com(0x80); //д��һ��ָ��
		for(j=0;j<16;j++) //д��һ������
		{
			write_data(table1[j]);
			delay_50us(10);
		}
		write_com(0x80+0x40);//д�ڶ���ָ��
		for(j=0;j<16;j++)	 //д�ڶ�������
		{
			write_data(table2[j]);
			delay_50us(10);
		}
   }
}				   