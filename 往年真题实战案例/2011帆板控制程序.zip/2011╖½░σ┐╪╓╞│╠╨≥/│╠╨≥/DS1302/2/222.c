#include <reg52.h>
#include <intrins.h>
#include <string.h>

#define uint unsigned int
#define uchar unsigned char

sbit IO=P3^4;
sbit CLK=P3^6;
sbit RST=P3^5;
sbit LCDRS=P2^4;
sbit LCDRW=P2^5;
sbit LCDE=P2^6;

uchar *WEEK[]={"SUN","***","MON","TUS","WEN","THU","FRI","SAT"};
uchar table1[]="DATA 00-00-00   ";
uchar table2[]="TIME 00:00:00   ";
uchar DateTime[7];

void DelayMS(uint x)
{
	uchar j;
	while(x--)for(j=0;j<120;j++);
}
//��DS1302д��һ�ֽ�
void Writr_A_Byte(uchar x)
{
	uchar i;
	for(i=0;i<8;i++)
	{
		IO=x&0x01;CLK=1;CLK=0;x>>=1;
	}
}
//��DS1302��ȡһ�ֽ�
uchar Get_A_Byte()
{
	uchar i,b=0x00;
	for(i=0;i<8;i++)
	{
		b|=_crol_((uchar)IO,i);
		CLK=1;CLK=0;
	}
	//BCD��ת��
	return b/16*10+b%16;
}
//��DS1302ָ��λ�ö�����
uchar Read_Data(uchar addr)
{
	uchar dat;
	RST=0;CLK=0;RST=1;
	Writr_A_Byte(addr);
	dat=Get_A_Byte();
	CLK=1;RST=0;
	return dat;
}

/*//��DS1302ĳ��ַд������
void Write_DS1302(uchar addr,uchar dat)
{
	CLK=0; RST=1;
	Writr_A_Byte(addr);
	Writr_A_Byte(dat);
	CLK=0; RST=0;
} */


//��ȡ��ǰʱ�䣨�롢�֡�ʱ��
void GetTime()
{
	uchar i,addr=0x81;
	for(i=0;i<7;i++)
	{
		DateTime[i]=Read_Data(addr)	;addr+=2;				
	}
}
//��LCD״̬
uchar Read_LCD_State()
{
	uchar state;
	LCDRS=0;LCDRW=1;LCDE=1;DelayMS(1);state=P0;LCDE=0;DelayMS(1);
	return state;
}

//æ�ȴ�
void LCD_Busy_Wait()
{
	while((Read_LCD_State()&0x80)==0x80);
	DelayMS(5);
}

//д����
void write_LCD_data(uchar dat)
{
	LCD_Busy_Wait();
	LCDRS=1;
	LCDRW=0;
	LCDE=0;
	P0=dat;
	LCDE=1;
	DelayMS(1);
	LCDE=0;	
}

 //дָ��
void write_com(uchar com)
{
	LCD_Busy_Wait();
	LCDRS=0;
	LCDRW=0;
	LCDE=0;
	P0=com;
	LCDE=1;
	DelayMS(1);
	LCDE=0;
}

//��ʼ��
void init()
{
	
	write_com(0x38);DelayMS(1);
	write_com(0x01);DelayMS(1);
	write_com(0x06);DelayMS(1);
	write_com(0x0c);DelayMS(1);

}

/*void Dispaly_LCD_String(uchar *a,uchar *b)
{
	uchar j;
	write_com(0x80); //д��һ��ָ��
	for(j=0;j<16;j++) //д��һ������
	{
		write_LCD_data(table1[j]);
		DelayMS(1);
	}
	write_com(0x80+0x40);//д�ڶ���ָ��
	for(j=0;j<16;j++)	 //д�ڶ�������
	{
		write_LCD_data(table2[j]);
		DelayMS(10);
	} 
} */
void Set_LCD_POS(uchar p)
{
	write_com(p|0x80);
}
void Dispaly_LCD_String(uchar p,uchar *s)
{
	uchar i;
	Set_LCD_POS(p);
	for(i=0;i<16;i++)
	{
		write_LCD_data(s[i]);
		DelayMS(1);
	}
}  


//������ʱ��ֵת��Ϊ�����ַ�
void Format_DateTime(uchar d,uchar *a)
{
	a[0]=d/10+'0';
	a[1]=d%10+'0';
}
void main ()
{
 	
	init();
	while(1);
	{	
		GetTime();

		//������
		Format_DateTime(DateTime[6],table1+5);
		Format_DateTime(DateTime[4],table1+8) ;
		Format_DateTime(DateTime[3],table1+11);
		//����

		strcpy(table1+13,WEEK[DateTime[5]]);
		//ʱ����
		Format_DateTime(DateTime[2],table2+5);
		Format_DateTime(DateTime[1],table2+8) ;
		Format_DateTime(DateTime[0],table2+11);
		//��ʾ
	   //Dispaly_LCD_String(table1,table2) ;
	  	 Dispaly_LCD_String(0x00,table1);
		 Dispaly_LCD_String(0x40,table2);
	}

}	
