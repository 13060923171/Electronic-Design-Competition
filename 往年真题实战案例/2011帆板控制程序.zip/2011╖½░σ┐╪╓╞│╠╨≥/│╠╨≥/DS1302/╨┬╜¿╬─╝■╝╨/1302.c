#include <reg52.h>
#include <intrins.h>

#define uint unsigned int
#define uchar unsigned char

sbit IO=P3^4;
sbit CLK=P3^6;
sbit RST=P3^5;
sbit K1=P1^1;
sbit K2=P1^2;
sbit K3=P1^3;

uchar Current_Time[7];
uchar Display_Buffer[7];
uchar  Adjust_Flag=0;


unsigned char code ziku[]=	{0xc0,0xf9,0xa4,0xb0,0x99, //0,1,2,3,4, 
							0x92,0x82,0xD8,0x80,0x90, //5,6,7,8,9,
							0x88,0x83,0xc6,0xa1,0x86, //A,B,C,D,E
							0x8e //F
							};
void delay_50us(uchar t);
void Writr_A_Byte(uchar x);
uchar Get_A_Byte();
void GetTime();
uchar Read_data(uchar addr);
void Write_DS1302(uchar addr,uchar dat);
 void SET_RTC() ;//����ʱ��

void delay_50us(uchar t)
{
	uchar j;
	for(;t>0;t--)
	for(j=19;j>0;j--);
}
//��DS1302д��һ�ֽ�
void Writr_A_Byte(uchar x)
{
	uchar i;
	for(i=0;i<8;i++)
	{
		IO=x&1;CLK=1;CLK=0;x>>=1;
	}
}
//��DS1302��ȡһ�ֽ�
uchar Get_A_Byte()
{
	uchar i,b,t;
	for(i=0;i<8;i++)
	{
		b>>=1;t=IO;b|=t<<7;CLK=1;CLK=0;
	}
	//BCD��ת��
	return b/16*10+b%16;
}
//��DS1302ָ��λ�ö�����
uchar Read_Data(uchar addr)
{
	uchar dat;
	RST=0;CLK=0;RST=1;
	Writr_A_Byte(addr);
	dat=Get_A_Byte();
	CLK=1;RST=0;
	return dat;
}

//��DS1302ĳ��ַд������
void Write_DS1302(uchar addr,uchar dat)
{
	CLK=0; RST=1;
	Writr_A_Byte(addr);
	Writr_A_Byte(dat);
	CLK=0; RST=0;
}

void SET_DS1302() //����ʱ��
{
	Write_DS1302(0x8e,0x00);
	Write_DS1302(0x82,(Current_Time[1]/10<<4) | (Current_Time[1]%10));
	Write_DS1302(0x84,(Current_Time[2]/10<<4) | (Current_Time[2]%10));
	Write_DS1302(0x8e,0x80);
}

//��ȡ��ǰʱ�䣨�롢�֡�ʱ��
void GetTime()
{
	Current_Time[0]=Read_Data(0x81);
	Current_Time[1]=Read_Data(0x83);
	Current_Time[2]=Read_Data(0x85);
}

void EX_INT0() interrupt 0
{
	if(K1==0)
	{
		Adjust_Flag=1;
		Current_Time[2]=(Current_Time[2]+1)%24;
	}
	else
	if(K2==0)
	{
		Adjust_Flag=1;
		Current_Time[1]=(Current_Time[1]+1)%60;
	}
	else
	if(K3==0)
	{
		SET_DS1302;
		Adjust_Flag=0;
	}
}  
void main ()
{
	uchar i;
	IE=0X81;
	IT0=0X01;

//	Current_Time[2]=12;
//	Current_Time[1]=12;
//	Current_Time[0]=12;

	while(1)
	{
		//if (Adjust_Flag==0)	
			GetTime;
		
		Display_Buffer[0]=ziku[Current_Time[2]/10];
		Display_Buffer[1]=ziku[Current_Time[2]%10];
		Display_Buffer[2]=0xbf;
		Display_Buffer[3]=ziku[Current_Time[1]/10];
		Display_Buffer[4]=ziku[Current_Time[1]%10];
		Display_Buffer[5]=0xbf;
		Display_Buffer[6]=ziku[Current_Time[0]/10];
		Display_Buffer[7]=ziku[Current_Time[0]%10];
	
	for(i=0;i<8;i++)
	{
		
			P2=i;
			P0=~Display_Buffer[i];
			delay_50us(55);	   //��̬��ʾ����
	}
	
}	}
