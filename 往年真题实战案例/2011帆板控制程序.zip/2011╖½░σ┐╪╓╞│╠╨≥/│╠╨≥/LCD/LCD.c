#include <reg52.h>
#define uint unsigned int
#define uchar unsigned char 

sbit LCDRS=P2^4;
sbit LCDRW=P2^5;
sbit LCDE=P2^6;

uchar table1[]="  WWW.GDCP.COM  ";
uchar table2[]="ABCDEFGHIJKLMNOP";

void delay_50us(uchar t)
{
	uchar j;
	for(;t>0;t--)
	for(j=19;j>0;j--);
}
//дָ��
void write_com(uchar com)
{
	LCDE=0;
	LCDRS=0;
	LCDRW=0;
	P0=com;
	delay_50us(10);
	LCDE=1;
	delay_50us(20);
	LCDE=0;
}
//д����
void write_data(uchar dat)
{
	LCDE=0;
	LCDRS=1;
	LCDRW=0;
	P0=dat;
	delay_50us(10);
	LCDE=1;
	delay_50us(20);
	LCDE=0;	
}
//��ʼ��
void init()
{
	delay_50us(30);
	write_com(0x38);
	delay_50us(100);
	write_com(0x38);
	delay_50us(100);
    write_com(0x38);
	write_com(0x38);
	write_com(0x08);
	write_com(0x01);
	write_com(0x06);
	write_com(0x0c);

}

void main()
{
	uchar j;
	init();
	write_com(0x80); //д��һ��ָ��
	for(j=0;j<16;j++) //д��һ������
	{
		write_data(table1[j]);
		delay_50us(10);
	}
	write_com(0x80+0x40);//д�ڶ���ָ��
	for(j=0;j<16;j++)	 //д�ڶ�������
	{
		write_data(table2[j]);
		delay_50us(10);
	}
	while(1);

}