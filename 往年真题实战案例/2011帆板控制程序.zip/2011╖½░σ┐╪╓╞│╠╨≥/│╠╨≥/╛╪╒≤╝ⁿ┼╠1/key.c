#include <reg52.h>
#define uint unsigned int
#define uchar unsigned char 

unsigned  code number[]= {  0xc0,0xf9,0xa4,0xb0,0x99, //0,1,2,3,4, 
							0x92,0x82,0xD8,0x80,0x90, //5,6,7,8,9,
							0x88,0x83,0xc6,0xa1,0x86, //A,B,C,D,E
							0x8e };	   //F

void delay_50us(uchar t)
{
	uchar j;
	for(;t>0;t--)
	for(j=19;j>0;j--);
}

void main()
{	
	uchar key_l,key_h,key;
	while(1)
	{		   
	P3=0xf0;
	key_l=P3;
	key_l=key_l&0xf0;
	if(key_l!=0xf0)
	{
		delay_50us(200);
		if(key_l!=0xf0)
		{
		 	key_l=P3&0xf0;			   //����

			key_l=key_l|0x0f;
			P3=key_l;
			key_h=P3;
			key_h=key_h&0x0f;		  //����

			key_l=key_l&0xf0;			   //�ض���

			key=key_l+key_h;			//�С��������ɴ���
		}
	}
	switch(key)
	{
		/*case 0xee: P0=~number[0];	break;

		case 0xde: P0=~number[1];	break;
		case 0xbe: P0=~number[2];	break;
		case 0x7e: P0=~number[3];	break;

		case 0xed: P0=~number[4];	break;
		case 0xdd: P0=~number[5];	break;
		case 0xbd: P0=~number[6];	break;
		case 0x7d: P0=~number[7];	break;

		case 0xeb: P0=~number[8];	break;
		case 0xdb: P0=~number[9];	break;
		case 0xbb: P0=~number[10];	break;
		case 0x7b: P0=~number[11];	break;

		case 0xe7: P0=~number[12];	break;
		case 0xd7: P0=~number[13];	break;
		case 0xb7: P0=~number[14];	break;
		case 0x77: P0=~number[15];	break;		*/


		case 0x7e: P0=~number[0];	break;	  	   //��ͬ�����Ĵ��벻һ����Ҫ��ʵ�ʵ�·�Ľӷ�
		case 0xbe: P0=~number[1];	break;
		case 0xde: P0=~number[2];	break;
		case 0xee: P0=~number[3];	break;

		case 0x7d: P0=~number[4];	break;
		case 0xbd: P0=~number[5];	break;
		case 0xdd: P0=~number[6];	break;
		case 0xed: P0=~number[7];	break;

		case 0x7b: P0=~number[8];	break;
		case 0xbb: P0=~number[9];	break;
		case 0xdb: P0=~number[10];	break;
		case 0xeb: P0=~number[11];	break;

		case 0x77: P0=~number[12];	break;
		case 0xb7: P0=~number[13];	break;
		case 0xd7: P0=~number[14];	break;
		case 0xe7: P0=~number[15];	break;


	} 
}	}