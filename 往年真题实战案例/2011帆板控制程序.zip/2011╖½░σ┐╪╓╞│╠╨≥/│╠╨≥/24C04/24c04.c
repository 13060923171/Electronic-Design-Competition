#include<reg52.h>
#include<intrins.h>
#include"lcd.h"
#define uint unsigned int 
#define uchar unsigned char
#define Delay4us() {_nop_();_nop_();_nop_();_nop_();}
sbit P10=P1^0;
sbit SCL=P1^1;
sbit SDA=P1^2;

uchar Count=0;

unsigned char code ziku[]=	{0xc0,0xf9,0xa4,0xb0,0x99, //0,1,2,3,4, 
							0x92,0x82,0xD8,0x80,0x90, //5,6,7,8,9,
							0x88,0x83,0xc6,0xa1,0x86, //A,B,C,D,E
							0x8e //F
							};
void delay(uint t)
{
	uint a,b;
	for(a=0;a<t;a++)
	for(b=0;b<255;b++);
}
////////////////////////////////////////////////////////////////////////////
//��ʱ
void DelayMS(uint ms)
{
	uchar t;
	while(ms--) for(t=0;t<120;t++);
}
//IIC����
void Start()
{
	SDA=1;SCL=1; Delay4us();SDA=0;Delay4us();SCL=0;
}
//IICֹͣ
void Stop()
{
	SDA=0;SCL=0;Delay4us();SCL=1;Delay4us();SDA=1;
}
//��ȡӦ��
void RACK()
{
	SDA=1;Delay4us();SCL=1;Delay4us();SCL=0;
}
//���ͷ�Ӧ���ź�
void NO_ACK()
{
	SDA=1;SCL=1;Delay4us();SCL=0;SDA=0;
}
//��24C04��дһ�ֽ�
void Write_A_Byte(uchar byte)
{
	uchar i;
	for(i=0;i<8;i++)	  //ѭ������8λ		  �Ӹ�λ����λ
	{
		byte<<=1;SDA=CY;_nop_();SCL=1;Delay4us();SCL=0;
	}
	RACK();
}
//��24C04�ж�һ�ֽ�
uchar Receive_A_Byte()
{
	uchar i,d;
	for(i=0;i<8;i++)
	{
		SCL=1;d<<=1;d|=SDA;SCL=0;
	}
	return d;
}
//�����ַд����
void Write_Random_Address_Byte(uchar add,uchar dat)
{
	Start();
	Write_A_Byte(0Xae);Write_A_Byte(add);Write_A_Byte(dat);	//������ַ����ַ������
	Stop();
	DelayMS(10);
}
//��ǰ��ַ������
uchar Read_Current_Address_Data()
{
	uchar dat;
	Start();
	Write_A_Byte(0xaf);dat=Receive_A_Byte();NO_ACK();
	Stop();
	return dat;
}
//�����ַ��ȡ����
uchar Random_Read(uchar addr)
{
	Start();
	Write_A_Byte(0xae);Write_A_Byte(addr);
	Stop();
	return Read_Current_Address_Data();
}
void main()
{	uchar a;
	P10=0;
	Count=Random_Read(0x00)+1;
	Write_Random_Address_Byte(0x00,Count);
	a=Count%10;

	
	
	while (1)
	{
	 		P0=~ziku[a];
	}
	

}


