#include"12864.h"
#include"key.h"
uchar table1[]="  ��1:����2:����";
uchar table2[]="�˩�3:����4:�¿�";
uchar table3[]="����5:����6:ͨѶ";
uchar table4[]="  ��7:����8:����";
uchar table5[]="                ";


void main()
{
	uchar aa;
	init_12864();
	Write_12864com(0X01);
	while(1)
	{	
		display_12864(0X80,table1);
		display_12864(0X90,table2);
		display_12864(0x88,table3);			
		display_12864(0x98,table4);
		delay__50us(200);

		//ȥ����
		con_disp(0x00,0x00,0X80,0x80,16,16);
		con_disp(0x00,0x00,0X90,0x90,16,16);
		con_disp(0x00,0x00,0X88,0x88,16,16);
		con_disp(0x00,0x00,0X98,0x98,16,16);  	 
		while(1)
		{
			
				aa=LCD12864_work();
		/*display_12864(0X80,table5);
		display_12864(0X90,table5);
		display_12864(0x88,table5);			
		display_12864(0x98,table5);	  */ 

		}
	
	}

}

