#ifndef __KEY_H__
#define __KEY_H__
#include <reg52.h>

#define uint unsigned int
#define uchar unsigned char 

extern uchar num;

void delay__50us(uchar t);
uchar KEY(void); //����1-15


#endif