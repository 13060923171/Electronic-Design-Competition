#include <reg52.h>
#define uint unsigned int
#define uchar unsigned char
sbit key1=P3^0;
sbit LED=P1^0;

unsigned code number[]={0xc0,0xf9,0xa4,0xb0,0x99, //0,1,2,3,4, 
						0x92,0x82,0xD8,0x80,0x90, //5,6,7,8,9,
						0x88,0x83,0xc6,0xa1,0x86, //A,B,C,D,E
						0x8e };	   //F
/*void delay_50us(uchar t)
{
	uchar j'
	for(;t>0;t--)
	for(j=19;j<0;j--);
}						 */

void main()
{
	uchar num=0;
	P3=0xff;
	while(1)
	{
		if(key1==0)
		{
			num++;
			LED=0;
			if(num>15)
			num=0;
			while(!key1);				//����Ƿ�����
		}
		else
		{
		 	LED=1;
			P0=~number[num];
		}
	}
}