#include"lcd.h"

/*void delay50us(void)   
{
  unsigned char a;
    for(a=40;a>0;a--);
}		 */
void delay_1ms(uchar t)   
{
    uchar a,b;
    for(;t>0;t--)
        for(b=20;b>0;b--)
            for(a=40;a>0;a--);
}
//д�������
void WriteCommand(unsigned char c)
{
 delay_1ms(1);
 LCDE=0;
 LCDRS=0;
 LCDRW=0;
 _nop_();
 LCDE=1;
 LCDData=c;
 LCDE=0;
}
/******************************************************************/
/*         д�����ݺ���                              */
/******************************************************************/
void WriteData(unsigned char c)
{
 delay_1ms(1);
 LCDE=0;
 LCDRS=1;
 LCDRW=0;
 _nop_();
 LCDE=1;
 LCDData=c;
 LCDE=0;
 LCDRS=0;
}
/******************************************************************/
/*              ��ʼ������                        */
/******************************************************************/
void InitLcd()
{
// DelayMs(15);
 WriteCommand(0x38); 
 WriteCommand(0x38);
 WriteCommand(0x38); 
 WriteCommand(0x06);
 WriteCommand(0x0c);
 WriteCommand(0x01);
}