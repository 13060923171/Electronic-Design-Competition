#include <reg52.h>
#define uint unsigned int
#define uchar unsigned char

unsigned char code number[]= {  0xc0,0xf9,0xa4,0xb0,0x99, //0,1,2,3,4, 
								0x92,0x82,0xD8,0x80,0x90, //5,6,7,8,9,
								0x88,0x83,0xc6,0xa1,0x86, //A,B,C,D,E
								0x8e };	   //F

uchar irtime;
uchar startflag;
uchar irdata[33];
uchar bitnum;
uchar irreceok;
uchar ircode[4];
uchar irprosok;
uchar disp[8];


void delay(uint t)
{
	uint a,b;
	for(a=0;a<t;a++)
	for(b=0;b<255;b++);
}
 //��ʱ��0��ʼ��
void timer0init(void)
{
	TMOD=0x02;
	TH0=0x00;
	TL0=0x00;
	ET0=1;
	EA=1;
	TR0=1;

}
 //�ⲿ�ж�0�ж�
void int0init(void)
{
	IT0=1;
	EX0=1;
	EA=1;
}

void irwork(void)
{
	disp[0]=ircode[0]/16;
	disp[1]=ircode[0]%16;
	disp[2]=ircode[1]/16;
	disp[3]=ircode[1]%16;
	disp[4]=ircode[2]/16;
	disp[5]=ircode[2]%16;
	disp[6]=ircode[3]/16;
	disp[7]=ircode[3]%16;
}

void display(void)
{
	uchar i;
	for(i=0;i<8;i++)
	{
		P2=i;
		P0=~number[disp[i]];
		delay(1);	   //��̬��ʾ����
		//delay(500);		  //��̬��ʾ���
	}
}

void irpros(void)
{
	uchar k,i,j;
	uchar value;
	k=1;
	for(j=0;j<4;j++)
	{
		for(i=0;i<8;i++)
		{
			value=value>>1;	
			if(irdata[k]>6)	//8     �ж�irdataΪ0��1
			{
				value=value|0x80;
			}
			k++;
		}
		ircode[j]=value;
	}
	irprosok=1;
}






void main()
{
	timer0init();
	int0init();
	while(1)
	{
		if(irreceok)
		{
			irpros();
			irreceok=0;	
		}
		if(irprosok)
		{
			irwork();
			irprosok=0;
		}	 
		display();	
	}	
}

void timer0 () interrupt 1
{
	irtime++;      //255
}

//irtime������ʱ�䣩װ������irdata(��������)
void int0 () interrupt 0
{
	if(startflag)
	{
	 	if(irtime>32) //���������
		{
			bitnum=0;
		}
		irdata[bitnum]=irtime;
		irtime=0;
		bitnum++;
		if(bitnum==33)
		{
			bitnum=0;
			irreceok=1;
		}
	}
	else
	{
		startflag=1;
		irtime=0;
	}
}

