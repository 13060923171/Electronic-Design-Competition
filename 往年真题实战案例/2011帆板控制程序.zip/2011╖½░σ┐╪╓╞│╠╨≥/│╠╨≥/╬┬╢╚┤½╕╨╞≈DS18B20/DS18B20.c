#include <reg52.h>
#include <intrins.h>
#define uint unsigned int
#define uchar unsigned char

sbit DQ=P1^3;
uchar temp;

unsigned char code ziku[]=	{0xc0,0xf9,0xa4,0xb0,0x99, //0,1,2,3,4, 
							0x92,0x82,0xD8,0x80,0x90, //5,6,7,8,9,
							0x88,0x83,0xc6,0xa1,0x86, //A,B,C,D,E
							0x8e //F
							};
void delay(uint t)
{

	while(t--);
	
}
//��ʼ��DS1820
void Init_DS18B20()
{
	uchar status;
	DQ=1;
	delay(8);
	DQ=0;delay(80);
	DQ=1;
	delay(8);
	status=DQ;
	delay(4);	
}
//��һ���ֽ�
uchar Readonebyte(void)
{
	uchar i,dat;
	
	for(i=0;i<8;i++)
	{
		DQ=0; 
		dat>>=1;
		DQ=1; 
		if(DQ) 
		dat|=0x80;
		delay(4);
	
	}
	return dat;
}
//дһ���ֽ�
void Writeonebyte(uchar dat)
{
	uchar i;
	for(i=0;i<8;i++)
	{
		DQ=0;
		DQ=dat&0x01;
		delay(4);
		DQ=1;
		dat>>=1;
	}
	delay(4);
}
//��ȡ�¶�ֵ
uchar Read_Temperature()
{
	uchar a,b;
	Init_DS18B20();
	Writeonebyte(0xCC);
	Writeonebyte(0x44);			 //�¶�ת��
	delay(300);

	Init_DS18B20();
	Writeonebyte(0xCC);
	Writeonebyte(0xBE);
	a=Readonebyte();
	b=Readonebyte();

	b<<=4;
	b+=(a&0xf0)>>4;
	return b;

}

void main()
{
	while(1)
	{
		temp=Read_Temperature();
		P2=0xff;
		P0=~ziku[temp%10];
		delay(1000);
		P2=0xfe;
		P0=~ziku[temp/10];
		delay(1000);
	}
}



