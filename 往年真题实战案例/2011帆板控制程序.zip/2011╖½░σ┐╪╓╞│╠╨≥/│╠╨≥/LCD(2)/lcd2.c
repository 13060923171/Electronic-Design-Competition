#include<reg52.h>
#include<intrins.h>
#define uchar unsigned uchar
#define uint unsigned int
#define LCDData P0 	//Һ�����ݶ˿�
sbit LCDRS=P2^4;
sbit LCDRW=P2^5;
sbit LCDE=P2^6;

void delay1ms(void)   
{
    unsigned char a,b,c;
    for(c=1;c>0;c--)
        for(b=20;b>0;b--)
            for(a=40;a>0;a--);
}
//д�������
void WriteCommand(unsigned char c)
{
 delay1ms();
 LCDE=0;
 LCDRS=0;
 LCDRW=0;
 _nop_();
 LCDE=1;
 LCDData=c;
 LCDE=0;
}
/******************************************************************/
/*         д�����ݺ���                              */
/******************************************************************/
void WriteData(unsigned char c)
{
 delay1ms();
 LCDE=0;
 LCDRS=1;
 LCDRW=0;
 _nop_();
 LCDE=1;
 LCDData=c;
 LCDE=0;
 LCDRS=0;
}
/******************************************************************/
/*              ��ʼ������                        */
/******************************************************************/
void InitLcd()
{
// DelayMs(15);
 WriteCommand(0x38); 
 WriteCommand(0x38);
 WriteCommand(0x38); 
 WriteCommand(0x06);
 WriteCommand(0x0c);
 WriteCommand(0x01);
}

//������
  main()
{  
   InitLcd();
   	WriteCommand(0x82);
	WriteData('T');
	WriteData('i');
	WriteData('a');
	WriteData('n');
	WriteData(' ');
	WriteData('H');
	WriteData('u');
	WriteData('a');
	WriteData(' ');
	WriteData('B');
	WriteData('e');
	WriteData('i');
 	WriteCommand(0x82+0x40);
	WriteData('1');
	WriteData('1');
	WriteData('0');
	WriteData('3');
	WriteData('2');
	WriteData('4');
	WriteData('0');
	WriteData('1');
	WriteData('0');
	WriteData('0');
	WriteData('3');
	while(1);	
}
