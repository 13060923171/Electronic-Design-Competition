#include "lcd.h"
#include "key.h"
#include <math.h>

uchar table1[]="  WWW.GDCP.COM  ";
uchar table2[]="                ";
uchar X,KeyNO=0;
////////////////////////////////////////////
uchar DSY_BUFFER[16]="                ";
uchar BUFFER[16]="                ";
uchar table[]="                ";
uint AA=0;
uint K;
uchar i=0,b=1;
////////////////////////////
void  shuru(uchar t)
{	
	DSY_BUFFER[i]=t+'0';	  //��ʾ����
	BUFFER[i]=t;			  //���뻺��
	i=i+1;
}
uchar keywork()
{
	uchar j,n;
	while(b==1)
	{
		P1=0xf0;		
		if(P1!=0xf0) 
		{
			KeyNO=KEY();			
			switch (KeyNO)
			{
				case 0: shuru(KeyNO);break;
				case 1: shuru(KeyNO);break;
				case 2: shuru(KeyNO);break;
				case 3: shuru(KeyNO);break;
				case 4:	shuru(KeyNO);break;
				case 5: shuru(KeyNO);break;
				case 6: shuru(KeyNO);break;
				case 7: shuru(KeyNO);break;
				case 8: shuru(KeyNO);break;
				case 9:	shuru(KeyNO);break;	
						
				case 10: i=i-1;
						 DSY_BUFFER[i]=' ';							 					  
						 if(i>16)	i=0;
						 break;	
	
				case 11:  for(n=0;n<i;n++)
						  {																								
						    AA=BUFFER[n]*(pow(10,i-n-1))+AA;
								   
						  }
							K=AA;
							AA=0;
							b=0;							
							for(n=0;n<i;n++)
							{
								BUFFER[n]=' ';
								DSY_BUFFER[n]=' ';	
							}
							i=0;
							break;							
					}		
				}			
			//table2[9]=num/10+'0';
			//table2[10]=(num%10)+'0';
		
			write_com(0x80);//д��һ��ָ��
			for(j=0;j<16;j++)	 //д��һ������
			{
				write_data(DSY_BUFFER[j]);
				delay_50us(10);
			}
			write_com(0x80+0x40); //д�ڶ���ָ��
			for(j=0;j<16;j++) //д�ڶ�������
			{
				write_data(table[j]);
				delay_50us(10);
			}		
	}
			b=1;
			return K;			  	
}
///////////////////////////////////////////
void main()
{
	uchar j,NO,a,b,c,d;
	init();					 ///
	while(1)
	{
///////////////////////////////////////////////	  //ֻ����һ������
/*	 	P1=0xf0;			   ///
		if(P1!=0xf0) 			//
		{
			X=keywork();		//			
		}							  */
//////////////////////////////////////////////////// ����������
		P1=0xf0;			   
		if(P1!=0xf0)
		{
	
			NO=KEY();			
			switch (NO)
			{
				case 12:a=keywork(); break;
				case 13:b=keywork(); break;
				case 14:c=keywork(); break;
				case 15:d=keywork(); break;	
			}	 
		}		
			
/*			table2[9]=X/10+'0';					 //
			table2[10]=(X%10)+'0';	*/			 //
			
			table2[0]=a/10+'0';					 
			table2[1]=(a%10)+'0';
			table2[3]=b/10+'0';					 
			table2[4]=(b%10)+'0';
			table2[6]=c/10+'0';					 
			table2[7]=(c%10)+'0';
			table2[9]=d/10+'0';					 
			table2[10]=(d%10)+'0';
					
			write_com(0x80); //д��һ��ָ��
			for(j=0;j<16;j++) //д��һ������
			{
				write_data(table1[j]);
				delay_50us(10);
			}		
			write_com(0x80+0x40);//д�ڶ���ָ��
			for(j=0;j<16;j++)	 //д�ڶ�������
			{
				write_data(table2[j]);
				delay_50us(10);
			}	  		
		}	
	}
	



