#include "key.h"

void delay__50us(uchar t)
{
	uchar j;
	for(;t>0;t--)
	for(j=19;j>0;j--);
}
uchar KEY(void)
{	
	uchar key_l,key_h,key,num=0;		   
	P1=0xf0;
	key_l=P1;
	key_l=key_l&0xf0;
	if(key_l!=0xf0)
	{
		delay__50us(200);
		if(key_l!=0xf0)
		{
		 	key_l=P1&0xf0;			   //����

			key_l=key_l|0x0f;
			P1=key_l;
			key_h=P1;
			key_h=key_h&0x0f;		  //����

			key_l=key_l&0xf0;			   //�ض���

			key=key_l+key_h;			//�С��������ɴ���
		}
	}	
	switch(key)
	{
			case 0x7e: num=4;		break;	  	   //��ͬ�����Ĵ��벻һ����Ҫ��ʵ�ʵ�·�Ľӷ�
			case 0xbe: num=3;		break;
			case 0xde: num=2;		break;
			case 0xee: num=1;		break;

			case 0x7d: num=8;		break;
			case 0xbd: num=7;		break;
			case 0xdd: num=6;		break;
			case 0xed: num=5;		break;

			case 0x7b: num=0x0b;	break;
			case 0xbb: num=0x0a;	break;
			case 0xdb: num=0;		break;
			case 0xeb: num=9;		break;

			case 0x77: num=0x0f;	break;
			case 0xb7: num=0x0e;	break;
			case 0xd7: num=0x0d;	break;
			case 0xe7: num=0x0c;	break;
	}
	P1=0xf0;		   //���ּ��
	if(P1!=0xf0)
	while(P1!=0xf0);
		 
	return num;
}
