#include "SPCE061V004.H"
//======================================================
//��ʱ
delay(unsigned int us)
{
	while(us--)
		*P_Watchdog_Clear=0x0001;
}
//======================================================
//���Ƕȴ�����
unsigned int uzz9001(void)
{
	unsigned int i,temp=0;
	*P_IOA_Dir|=0x0003; //��λ����Ϊcs��IOA2��,sck,sda
	*P_IOA_Dir&=0xfffb;
	*P_IOA_Attrib|=0x0003;
	*P_IOA_Attrib&=0xfffb;
	*P_IOA_Data=*P_IOA_Buffer|0x0007;
	*P_IOA_Data=*P_IOA_Buffer&0xfffe;//cs=0
	i=16;
	while(i--)
	{
		temp<<=1;
		*P_IOA_Data=*P_IOA_Buffer&0xfffd; //SCK=0
		*P_Watchdog_Clear=0x0001;
		*P_IOA_Data=*P_IOA_Buffer|0x0002; //SCK=1
		if(*P_IOA_Data&0x0004)
			temp|=0x0001;
		else
			temp&=0xfffe;
	}
	*P_IOA_Data=*P_IOA_Buffer|0x0001;
	return(temp);
}
//======================================================
//����Ƕ�
float anglee(void)
{
	unsigned int temp0,temp1;
	float jiaodu;
	temp0=uzz9001();
	temp1=temp0&0x3f00;
	temp1>>=1;
	temp0&=0x007f;
	temp0=temp0+temp1;
	jiaodu=temp0*180.001/8192.001;
	return(jiaodu);
}
//======================================================
//��8�νǶ���ƽ��ֵ
float angle(void)
{
	unsigned int i;
	float jiaodu=0;
	for(i=0;i<8;i++)
	{
		jiaodu+=anglee();
	}
	jiaodu/=8;
	return(jiaodu);
}
//======================================================
//��ȡ��ʼ�Ƕ�
float chujiao(void)
{
	unsigned int i;
	float temp;
	for(i=0;i<100;i++)
	{
		temp+=angle();
	}
	temp/=100;
	return(temp);
}
//======================================================
//
main()
{
	float data;
	float zuo,you;
	unsigned int temp;
//	while(1)
//	{
//		zuo=chujiao()+120;
//		if(zuo<180)
//			break;
//	}
	while(1)
	{
		data=angle();
		if(data>100)
			data-=60;
		else
			data+=120;
		temp=*P_IOB_Buffer&0xff0f;
		if(data<95.07)
			*P_IOB_Data=temp+0x0000;
		else if(data>=95.07&&data<101.32)
			*P_IOB_Data=temp+0x0010;
		else if(data>=101.32&&data<103.41)
			*P_IOB_Data=temp+0x0020;
		else if(data>=103.41&&data<104.1)
			*P_IOB_Data=temp+0x0040;
		else if(data>=104.1&&data<105.05)
			*P_IOB_Data=temp+0x0050;
		else if(data>=105.05&&data<105.75)
			*P_IOB_Data=temp+0x0060;
		else if(data>=105.75&&data<107.58)
			*P_IOB_Data=temp+0x0080;
		else if(data>=107.58&&data<113.83)
			*P_IOB_Data=temp+0x0090;
		else if(data>=113.83)
			*P_IOB_Data=temp+0x00a0;
	}
}