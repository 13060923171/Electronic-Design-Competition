#include"12864.h"
uchar table1[]="�㶫��ְͨҵ����";
uchar table2[]="ѧԺ2011-08-25  ";


void display_12864(uchar dat,uchar table[])
{
	uchar i;
	Write_12864com(dat);
	for(i=0;i<16;i++)
	{
		Write_12864dat(table[i]);
		delay__50us(1);
	}	
}	
void main()
{
	init_12864();
	while(1)
	{
		display_12864(0x80,table1);
		display_12864(0x88,table2);	
	//	delay__50us(20000);

	//	Write_12864com(0x3f);	   ///
	//	Write_12864com(0x07);
	//	delay__50us(1);


///	Write_12864com(0x80);
//	Write_12864dat(0xff);
	

		while(1);
	}

}