#ifndef __12864_H__
#define __12864_H__

#include<reg52.h>
#define uint unsigned int
#define uchar unsigned char

sbit RS=P2^4;
sbit RW=P2^5;
sbit E=P2^6;
sbit PSB=P2^7; 


void Write_12864com(uchar com);
void Write_12864dat(uchar dat);
void init_12864(void);
void delay__50us(uint t);

#endif