#include"ir.h"

uchar irtime;
uchar startflag;
uchar irdata[33];
uchar bitnum;
uchar irreceok;
uchar ircode[4];
uchar irprosok;
uchar disp[8];

uchar num=0;


/*void delay(uint t)
{
	uint a,b;
	for(a=0;a<t;a++)
	for(b=0;b<255;b++);
} */
 //��ʱ��0��ʼ��
void timer0init(void)
{
	TMOD=0x02;
	TH0=0x00;
	TL0=0x00;
	ET0=1;
	EA=1;
	TR0=1;

}
 //�ⲿ�ж�0�ж�
void int0init(void)
{
	IT0=1;
	EX0=1;
	EA=1;
}

/*void irwork(void)
{
	disp[0]=ircode[0]/16;
	disp[1]=ircode[0]%16;
	disp[2]=ircode[1]/16;
	disp[3]=ircode[1]%16;
	disp[4]=ircode[2]/16;
	disp[5]=ircode[2]%16;
	disp[6]=ircode[3]/16;
	disp[7]=ircode[3]%16;
} */


void irpros(void)
{
	uchar k,i,j;
	uchar value;
	k=1;
	for(j=0;j<4;j++)
	{
		for(i=0;i<8;i++)
		{
			value=value>>1;	
			if(irdata[k]>6)	//8     �ж�irdataΪ0��1
			{
				value=value|0x80;
			}
			k++;
		}
		ircode[j]=value;
	}
	irprosok=1;
}
/////////////////////////////////////////////////

///////////////////////////////////////////////////
uchar ir_keywork()
{
	timer0init();
	int0init();
	if(irreceok)
	{
		irpros();
		irreceok=0;	
	}
	if(irprosok)
	{
	//	irwork();
		irprosok=0;
	}	 
	switch (ircode[3])
	{
		case 0xe9: num=0;		break;
		case 0xf3: num=1;		break;
		case 0xe7: num=2;		break;
		case 0xa1: num=3;		break;
		case 0xf7: num=4;		break;	   	
		case 0xe3: num=5;		break;
		case 0xa5: num=6;		break; 
		case 0xbd: num=7;		break;
		case 0xad: num=8;		break;
		case 0xb5: num=9;		break;

	//	case 0xba: num=0x0a;		break;	   //ch-
	//	case 0xb9: num=0x0b;		break;	   //ch
	//	case 0xb8: num=0x0c;		break;	   //ch+
	//	case 0xbb: num=0x0d;		break;	   //prev
	//	case 0xbf: num=0x0e;		break;	   //next
	//	case 0xbc: num=0x0f;		break;	   //play/pause
		case 0xf8: num=0x0a; 	break;	//	-
		case 0xea: num=0x0b;		break;	//  +
		case 0xf6: num=0xf6;		break;	 //EQ
	}
	return num;				
}

void timer0 () interrupt 1
{
	irtime++;      //255
}

//irtime������ʱ�䣩װ������irdata(��������)
void int0 () interrupt 0
{
	if(startflag)
	{
	 	if(irtime>32) //���������
		{
			bitnum=0;
		}
		irdata[bitnum]=irtime;
		irtime=0;
		bitnum++;
		if(bitnum==33)
		{
			bitnum=0;
			irreceok=1;
		}
	}
	else
	{
		startflag=1;
		irtime=0;
	}
}

