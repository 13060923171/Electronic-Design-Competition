#ifndef __IR_H__
#define __IR_H__
#include <reg52.h>
#define uint unsigned int
#define uchar unsigned char

extern uchar num;

uchar ir_keywork();
#endif
