#include"X9313.h"
sbit key1=P1^0;
sbit key2=P1^1;

//------------------------------------------------------------------------

void keyscan()
{
	if(key1==0)
		{
			delay_xms(1);
			if(key1==0)
				move_up_x(1);
			while(!key1);
		}
	if(key2==0)
		{
			delay_xms(1);
			if(key2==0)
				move_down_x(1);
			while(!key2);
		}

}

//------------------------------------------------------------------------



void main()
{
	
	X9313W_SetVol(0); //�������赽��RNumber����ֵ 		 ���31����ֵ
	while(1)
	{
		keyscan();
	}
}	
