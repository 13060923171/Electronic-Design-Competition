#include "lcd.h"
#include "key.h"
#include "keywork.h"

uchar table1[]="  WWW.GDCP.COM  ";
uchar table2[]="                ";
uchar NO=0;
uchar X,a,b1,c,d;

///////////////////////////////////////////
void main()
{
	uchar j,NO;
	init();					 ///
	while(1)
	{
///////////////////////////////////////////////	  //ֻ����һ������
/*	 	P1=0xf0;			   ///
		if(P1!=0xf0) 			//
		{
			X=keywork();		//			
		}							  */
//////////////////////////////////////////////////// ����������
		P1=0xf0;			   
		if(P1!=0xf0)
		{
	
			NO=KEY();			
			switch (NO)
			{
				case 12:a=keywork(); break;
				case 13:b1=keywork(); break;
				case 14:c=keywork(); break;
				case 15:d=keywork(); break;	
			}	 
		}		
			
/*			table2[9]=X/10+'0';					 //
			table2[10]=(X%10)+'0';	*/			 //
			
			table2[0]=a/10+'0';					 
			table2[1]=(a%10)+'0';
			table2[3]=b1/10+'0';					 
			table2[4]=(b1%10)+'0';
			table2[6]=c/10+'0';					 
			table2[7]=(c%10)+'0';
			table2[9]=d/10+'0';					 
			table2[10]=(d%10)+'0';


					
			write_com(0x80); //д��һ��ָ��
			for(j=0;j<16;j++) //д��һ������
			{
				write_data(table1[j]);
				delay_50us(10);
			}		
			write_com(0x80+0x40);//д�ڶ���ָ��
			for(j=0;j<16;j++)	 //д�ڶ�������
			{
				write_data(table2[j]);
				delay_50us(10);
			}	  		
		}	
	}
	



