#include "key.h"

void delay__50us(uchar t)
{
	uchar j;
	for(;t>0;t--)
	for(j=19;j>0;j--);
}

uchar KEY(void)
{	
		uchar key_l,key_h,key,num=0;
		   
	P2=0xf0;
	key_l=P2;
	key_l=key_l&0xf0;
	if(key_l!=0xf0)
	{
		delay__50us(200);
		if(key_l!=0xf0)
		{
		 	key_l=P2&0xf0;			   //����

			key_l=key_l|0x0f;
			P2=key_l;
			key_h=P2;
			key_h=key_h&0x0f;		  //����

			key_l=key_l&0xf0;			   //�ض���

			key=key_l+key_h;			//�С��������ɴ���
		}
	}
	
	switch(key)
	{
		/*case 0xee: P0=~number[0];	break;

		case 0xde: P0=~number[1];	break;
		case 0xbe: P0=~number[2];	break;
		case 0x7e: P0=~number[3];	break;

		case 0xed: P0=~number[4];	break;
		case 0xdd: P0=~number[5];	break;
		case 0xbd: P0=~number[6];	break;
		case 0x7d: P0=~number[7];	break;

		case 0xeb: P0=~number[8];	break;
		case 0xdb: P0=~number[9];	break;
		case 0xbb: P0=~number[10];	break;
		case 0x7b: P0=~number[11];	break;

		case 0xe7: P0=~number[12];	break;
		case 0xd7: P0=~number[13];	break;
		case 0xb7: P0=~number[14];	break;
		case 0x77: P0=~number[15];	break;		*/


//			case 0x7e: num=7;	break;	  	   //��ͬ�����Ĵ��벻һ����Ҫ��ʵ�ʵ�·�Ľӷ�
			case 0xbe: num=9;	break;
			case 0xde: num=5;	break;
			case 0xee: num=1;	break;

//		case 0x7d: num=8;	break;
			case 0xbd: num=0;	break;
			case 0xdd: num=6;	break;
			case 0xed: num=2;	break;

//		case 0x7b: num=8;	break;
//		case 0xbb: num=9;	break;
			case 0xdb: num=7;	break;
			case 0xeb: num=3;	break;

//		case 0x77: num=2;	break;
//		case 0xb7: num=3;	break;
			case 0xd7: num=8;	break;
			case 0xe7: num=4;	break;


	} 
	return num*10;
}
