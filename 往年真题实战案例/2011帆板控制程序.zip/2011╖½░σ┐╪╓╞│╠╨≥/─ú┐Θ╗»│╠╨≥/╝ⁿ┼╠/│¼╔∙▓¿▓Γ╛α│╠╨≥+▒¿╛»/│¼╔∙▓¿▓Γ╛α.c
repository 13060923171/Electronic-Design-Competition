#include <reg52.h>
#include<intrins.h>
#include "key.h" 
#define uint unsigned int
#define uchar unsigned char
sbit LCDRS=P2^4;
sbit LCDRW=P2^5;
sbit LCDE=P2^6;
//sbit DQ=P1^3;
 sbit AA=P2^0;

sbit CSBin=P3^2;
sbit CSBout=P3^1;
sbit warn=P3^3;
uchar flag=0;//�жϱ�־λ
uchar high_time,low_time;
uint dis,temp,warnD,warnDD;
//////////////////////////////////////////
uchar table1[]="warning dis:    ";
uchar table2[]="Distance:   . CM";



/////////////////////////////////////////
void delay_50us(uchar t)
{
	uchar j;
	for(;t>0;t--)
	for(j=38;j>0;j--);
}
//дָ��
void write_com(uchar com)
{
	LCDE=0;
	LCDRS=0;
	LCDRW=0;
	P0=com;
	delay_50us(10);
	LCDE=1;
	delay_50us(20);
	LCDE=0;
}
//д����
void write_data(uchar dat)
{
	LCDE=0;
	LCDRS=1;
	LCDRW=0;
	P0=dat;
	delay_50us(10);
	LCDE=1;
	delay_50us(20);
	LCDE=0;	
}
//��ʼ��
void LCDinit()
{
	delay_50us(30);
	write_com(0x38);
	delay_50us(100);
	write_com(0x38);
	delay_50us(100);
    write_com(0x38);
	write_com(0x38);
	write_com(0x08);
	write_com(0x01);
	write_com(0x06);
	write_com(0x0c);

}
/////////////////////////////////
void send(void)
{

	TMOD=0x02;
	TH0=232;
	TL0=232;
//    TH1=0xfe;
//	TL1=0x0c;
	ET0=1;
    
	EA=1;
 	TR0=1;//����ʱ��0
//	TR1=1;
	
	delay_50us(3);


	EA=0;
	ET0=0;
// 	TR1=0;
	CSBout=0;
 }
void Tinit()
{
	TMOD=0x01;//��ʱ��0������ʽ1
	TH0=0;
	TL0=0;
	EA=1;
	IT0=1;//
	TR0=1;//����ʱ��0		
}



/*
void tran(void)
{
	uchar i;
	TH0=0;
	TL0=0;
	TR0=1;//����ʱ��0

	for(i=10;i>0;i--)
	{
		CSBout=!CSBout;
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	}



	delay_50us(10);//��ʱ1MS
	EX0=1;
	if(flag==1)
	{
		temp=high_time*256+low_time;
		temp=(temp/1000)/2;
		temp=temp*340;
		temp=temp/10;
		dis=(unsigned int)temp;
		flag=0;	
	}
}
*/
void display()
{
	uchar j;
	
	if(flag==1)
	{
		temp=high_time*256+low_time;		
		temp=(temp*0.34)/4;
		dis=temp;
		flag=0;	
		
	}
	table2[9]=dis/1000+'0';
	table2[10]=(dis%1000)/100+'0';

	table2[11]=(dis%100)/10+'0';
//	table2[12]=(dis%100/10)+'0';
	table2[13]=dis%10+'0';

	table1[12]=(warnD%10000)/1000+'0';
	table1[13]=(warnD%1000)/100+'0';
	table1[14]=(warnD%100/10)+'0';
	table1[15]=warnD%10+'0';



	write_com(0x80); //д��һ��ָ��
	for(j=0;j<16;j++) //д��һ������
	{
		write_data(table2[j]);
		delay_50us(10);
	}
	write_com(0x80+0x40);//д�ڶ���ָ��
	for(j=0;j<16;j++)	 //д�ڶ�������
	{
		write_data(table1[j]);
		delay_50us(10);
	}
	
	warnDD=warnD*10;
	if((warnDD)>dis)
//	{	uchar i;
//		for(i=0;i>100;i--)
//		{	
			warn=1;
//			delay_50us(dis/10);
//			warn=0;
	
//		}
//	}
	//	warn=1;
		else
	{
		warn=0;	
	}	
	dis=0;
	
}

void main()
{
	

	LCDinit();
	CSBout=0;
	CSBin=0;
 
 	while(1)
	{

	   send();
	   Tinit();
	   delay_50us(10);
	   EX0=1;
	   warnD=KEY();
	   display();
/*	   TMOD=0x10;
	   TL1=0;
	   TH1=0;
	   TR1=1;
	   EA=1;				 */

	}	
}

void int0() interrupt 0
{
//	uint tmp;
	TR0=0;	//�ض�ʱ��
	ET0=0;	//���ⲿ�ж�
	flag=1;//���жϺ���־λ
//	tmp=TH0*256+TL0;
//	if((tmp>0)&&(tmp<60000))
//	{
		high_time=TH0;
		low_time=TL0;
//	}
//	else
//	{
//		high_time=0;
//		low_time=0;
//	}  
}
void intT0() interrupt 1
{

   	CSBout=!CSBout;

}




