#include<reg52.h>
#define uint unsigned int
#define uchar unsigned char
uchar ucT0;
uchar PWM=0;
bit Flag=1;
sbit LED=P1^0;
void Timer0_Init(void);
void delayms(uint z)
{
	uint x,y;
	for(x=z;x>0;x--)
	for(y=110;y>0;y--);
}
void main()
{
	ET0=1;
	TMOD=0x02;
	TH0=0x47;
	TL0=0x47;
	TR0=1;
	EA=1;
while(1)
{
	delayms(100);	 //����ʱ��Ŀ���
	if(Flag)			//ռ�ձȵĵ���
	PWM++;
	else
	PWM--;
	if(PWM>=10) Flag=0;
	if(PWM==0) Flag=1;
}
}
void Timer0(void) interrupt 1  
{
	ucT0++;
	if(ucT0==10)
	{
		ucT0=0;
		if(PWM!=0)
		LED=0;
	}
	if(ucT0==PWM)
	{
		LED=1;
	}
}