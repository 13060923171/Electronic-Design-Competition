#include<reg52.h>
#define uint unsigned int
#define uchar unsigned char
uchar ucT0;
uchar PWM=0;
bit Flag=1;
sbit  K1=P1^0 ;                    //ռ�ձ����Ӽ� 
sbit  K2=P1^1 ;                    //���ټ� 
sbit  K3=P1^2;					   //Ƶ�ʼ�
sbit  K4=P1^3;
sbit LED=P1^4; 
void Timer0_Init(void);
void delayms(uint z)
{
	uint x,y;
	for(x=z;x>0;x--)
	for(y=110;y>0;y--);
}
void main()
{
	ET0=1;
	TMOD=0x02;
	TH0=0x47;
	TL0=0x47;
	TR0=1;
	EA=1;
	while(1)
	{
		if(K1==0)
		{
			delayms(1);
			if(K1==0)
			{
				PWM++;
				while(K1==0);
			}
		}
		if(K2==0)
		{
			delayms(1);
			if(K2==0)
			{
				PWM--;
				while(K2==0);
			}	
		}
	  	if(PWM>=10) PWM=10; 
		if(PWM==0) PWM=1;
	}
}		

void Timer0(void) interrupt 1  
{
	ucT0++;
	if(ucT0==10)
	{
		ucT0=0;
	//	if(PWM!=0)
		LED=1;
	}
	if(ucT0==PWM)
	{
		LED=0;
	}
}