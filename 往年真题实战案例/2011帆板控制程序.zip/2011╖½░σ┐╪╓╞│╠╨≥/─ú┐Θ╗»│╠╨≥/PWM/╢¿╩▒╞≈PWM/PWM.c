
#include < reg52.h > 
#include < intrins.h > 
#define uint unsigned int
#define uchar unsigned char


sbit  K1=P1^0 ;                    //ռ�ձ����Ӽ� 
sbit  K2=P1^1 ;                    //���ټ� 
sbit  K3=P1^2;					   //Ƶ�ʼ�
sbit  K4=P1^3;
sbit LED=P1^4;              // PWM ���
uchar PWM=0xce,f=0x9c ;   //����ֵ 



void delay(uchar t)
{
	while(t--);
}
void main ()
{
	TMOD=0x22;	   //T0��T1Ϊ��ʽ2
	TH0=0x9c;		//����Ƶ��Ϊ10KHZ��������100US
	TL0=0x9c;		 //Ƶ�ʵ���

	TH1=PWM;		 //��������
	TL1=PWM;

	EA=1;			 //�����ж�
	ET0=1;
	ET1=1;
	TR0=1;
	TR1=0;
	while(1)
	{
		if(K1==0)
		{
		//	if(PWM!=f)
		//	{
				delay(10);
				if(K1==0)
				{
					PWM++;
					while(K1==0);
				}
		//	}
		}
		if(K2==0)
		{
		//	if(PWM!=0)
		//	{
				delay(10);
				if(K2==0)
				{
					PWM--;
					while(K2==0);
		//		}
				
			}	
		}
/*	   if(K3==0)
		{			
			delay(10);
			if(K3==0)
			{
				f++;
				while(K3==0);
			}			
		}
		if(K4==0)
		{
			delay(10);
			if(K4==0)
			{
				f--;
				while(K4==0);
			}			
		}	  */
	}
}		

void timer0() interrupt 1
{
//	TR0=0; //
	TH1=PWM;
	TL1=PWM;
	TR1=1;		   
//	TH0=f;	//
//	TL0=f;	//
//	TR0=1; //
	LED=0;
}

void timer1() interrupt 3
{
	TR1=0;
	LED=1;
}


