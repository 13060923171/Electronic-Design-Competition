#ifndef __24C04_H__
#define __24C04_H__
#include<reg52.h>
#include<intrins.h>
#define uint unsigned int 
#define uchar unsigned char
#define Delay4us() {_nop_();_nop_();_nop_();_nop_();}
sbit P10=P1^0;
sbit SCL=P1^1;
sbit SDA=P1^2;


void Write_A_Byte(uchar byte);
uchar Receive_A_Byte();
void Write_Random_Address_Byte(uchar add,uchar dat);
uchar Read_Current_Address_Data();
uchar Random_Read(uchar addr);
#endif
