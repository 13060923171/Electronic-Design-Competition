#include"24C04.h"
uchar Count;
unsigned char code ziku[]=	{0xc0,0xf9,0xa4,0xb0,0x99, //0,1,2,3,4, 
							0x92,0x82,0xD8,0x80,0x90, //5,6,7,8,9,
							0x88,0x83,0xc6,0xa1,0x86, //A,B,C,D,E
							0x8e //F
							};

void main()
{	uchar a;
	P10=0;
	Count=Random_Read(0x00)+1;
	Write_Random_Address_Byte(0x00,Count);
	a=Count%10;

	
	
	while (1)
	{
	 		P0=~ziku[a];
	}
	

}