#include"lcd.h" 
 main()
{  
   	InitLcd();
   	WriteCommand(0x82);
	WriteData('T');
	WriteData('i');
	WriteData('a');
	WriteData('n');
	WriteData(' ');
	WriteData('H');
	WriteData('u');
	WriteData('a');
	WriteData(' ');
	WriteData('B');
	WriteData('e');
	WriteData('i');
 	WriteCommand(0x82+0x40);
	WriteData('1');
	WriteData('1');
	WriteData('0');
	WriteData('3');
	WriteData('2');
	WriteData('4');
	WriteData('0');
	WriteData('1');
	WriteData('0');
	WriteData('0');
	WriteData('3');
	while (1);
}