#ifndef __LCD_H__
#define __LCD_H__
#include <reg52.h>
#include<intrins.h>
#define uint unsigned int
#define uchar unsigned char 
#define LCDData P0 	//Һ�����ݶ˿�
sbit LCDRS=P2^4;
sbit LCDRW=P2^5;
sbit LCDE=P2^6;

void WriteCommand(unsigned char c);
void WriteData(unsigned char c);
void InitLcd();



#endif